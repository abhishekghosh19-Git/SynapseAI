import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface TypingIndicatorProps {
  modelName?: string;
}

export default function TypingIndicator({ modelName = "AI" }: TypingIndicatorProps) {
  return (
    <div className="flex gap-3" data-testid="typing-indicator">
      <Avatar className="h-8 w-8 bg-gradient-to-br from-violet-500 to-indigo-600 flex-shrink-0">
        <AvatarFallback className="text-white text-xs font-medium">AI</AvatarFallback>
      </Avatar>
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">{modelName} is thinking...</span>
        </div>
        <div className="flex items-center gap-1.5 px-4 py-3 bg-card border border-card-border rounded-2xl rounded-bl-md">
          <div className="flex gap-1">
            <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce [animation-delay:-0.3s]" />
            <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce [animation-delay:-0.15s]" />
            <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" />
          </div>
        </div>
      </div>
    </div>
  );
}
