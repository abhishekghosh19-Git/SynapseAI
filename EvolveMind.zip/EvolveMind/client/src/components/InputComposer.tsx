import { useState, useRef, useEffect } from "react";
import { Send, Paperclip, Sparkles, ChevronUp, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import PromptTechniqueBadge, { type PromptTechnique } from "./PromptTechniqueBadge";
import VoiceInput from "./VoiceInput";

export interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  uploadedAt: Date;
  preview?: string;
}

interface InputComposerProps {
  onSend: (message: string, techniques: PromptTechnique[]) => void;
  isLoading?: boolean;
  activeTechniques: PromptTechnique[];
  onTechniqueRemove: (id: string) => void;
  onOpenTechniqueLibrary: () => void;
  onFilesSelected?: (files: UploadedFile[]) => void;
  placeholder?: string;
}

const formatFileSize = (bytes: number) => {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
};

export default function InputComposer({
  onSend,
  isLoading = false,
  activeTechniques,
  onTechniqueRemove,
  onOpenTechniqueLibrary,
  onFilesSelected,
  placeholder = "Type your message... (Shift+Enter for new line)",
}: InputComposerProps) {
  const [message, setMessage] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [message]);

  const handleSend = () => {
    if (message.trim() && !isLoading) {
      onSend(message.trim(), activeTechniques);
      setMessage("");
      setUploadedFiles([]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFiles = (fileList: FileList) => {
    const newFiles: UploadedFile[] = [];
    for (let i = 0; i < Math.min(fileList.length, 5); i++) {
      const file = fileList[i];
      const preview = file.type.startsWith("image/")
        ? URL.createObjectURL(file)
        : undefined;

      newFiles.push({
        id: `file-${Date.now()}-${i}`,
        name: file.name,
        type: file.type,
        size: file.size,
        uploadedAt: new Date(),
        preview,
      });
    }
    const combined = [...uploadedFiles, ...newFiles];
    setUploadedFiles(combined);
    onFilesSelected?.(combined);
  };

  const removeFile = (id: string) => {
    const updated = uploadedFiles.filter(f => f.id !== id);
    setUploadedFiles(updated);
    onFilesSelected?.(updated);
  };

  return (
    <div className="border-t border-border bg-background p-4 space-y-3">
      {activeTechniques.length > 0 && (
        <div className="flex flex-wrap gap-2 pb-2 border-b border-border">
          <span className="text-xs text-muted-foreground self-center mr-1">Active:</span>
          {activeTechniques.map((technique) => (
            <PromptTechniqueBadge
              key={technique.id}
              technique={technique}
              isRemovable
              onRemove={() => onTechniqueRemove(technique.id)}
            />
          ))}
        </div>
      )}

      {/* Uploaded files preview */}
      {uploadedFiles.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {uploadedFiles.map((file) => (
            <div
              key={file.id}
              className="flex items-center gap-2 px-2 py-1.5 rounded-md bg-muted text-sm"
              data-testid={`uploaded-file-badge-${file.id}`}
            >
              {file.preview ? (
                <img
                  src={file.preview}
                  alt={file.name}
                  className="h-4 w-4 rounded object-cover"
                />
              ) : (
                <Paperclip className="h-3.5 w-3.5 text-muted-foreground" />
              )}
              <span className="truncate text-xs">{file.name}</span>
              <span className="text-xs text-muted-foreground">({formatFileSize(file.size)})</span>
              <button
                onClick={() => removeFile(file.id)}
                className="hover:text-foreground transition-colors"
                data-testid={`button-remove-file-${file.id}`}
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-end gap-2">
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            onDragOver={() => setIsDragging(true)}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              handleFiles(e.dataTransfer.files);
            }}
            placeholder={placeholder}
            className={`min-h-[44px] max-h-[200px] resize-none pr-12 py-3 text-sm transition-colors ${
              isDragging ? "bg-primary/5 border-primary" : ""
            }`}
            disabled={isLoading}
            data-testid="input-message"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-1 bottom-1 h-8 w-8"
            onClick={onOpenTechniqueLibrary}
            data-testid="button-open-techniques"
          >
            <Sparkles className="h-4 w-4 text-primary" />
          </Button>
        </div>

        <div className="flex gap-1">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,.txt,.md,.json,.pdf"
            onChange={(e) => e.target.files && handleFiles(e.target.files)}
            className="hidden"
            data-testid="file-input"
          />
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10"
            onClick={() => fileInputRef.current?.click()}
            data-testid="button-attach"
          >
            <Paperclip className="h-4 w-4" />
          </Button>
          <VoiceInput
            onTranscript={(text) => setMessage((prev) => (prev ? prev + " " + text : text))}
            isLoading={isLoading}
          />
          <Button
            onClick={handleSend}
            disabled={!message.trim() || isLoading}
            className="h-10 px-4 gap-2"
            data-testid="button-send"
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <Send className="h-4 w-4" />
                <span className="hidden sm:inline">Send</span>
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Press Enter to send, Shift+Enter for new line</span>
        <button
          onClick={onOpenTechniqueLibrary}
          className="flex items-center gap-1 hover:text-foreground transition-colors"
          data-testid="button-techniques-hint"
        >
          <ChevronUp className="h-3 w-3" />
          Prompt Techniques
        </button>
      </div>
    </div>
  );
}
