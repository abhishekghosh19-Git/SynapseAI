import { X, Minimize2, TrendingUp } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface CompressionIndicatorProps {
  compressionRatio: number;
  tokensUsed: number;
  maxTokens: number;
  tokensSaved: number;
}

export default function CompressionIndicator({
  compressionRatio,
  tokensUsed,
  maxTokens,
  tokensSaved,
}: CompressionIndicatorProps) {
  const [isDismissed, setIsDismissed] = useState(false);
  const usagePercent = (tokensUsed / maxTokens) * 100;

  if (isDismissed) return null;

  return (
    <div
      className="flex items-center gap-4 px-4 py-2 bg-gradient-to-r from-primary/5 to-violet-500/5 border-b border-primary/10"
      data-testid="compression-indicator"
    >
      <div className="flex items-center gap-2">
        <Minimize2 className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium">Context Compression</span>
      </div>

      <div className="flex-1 flex items-center gap-4">
        <div className="flex items-center gap-2 min-w-[120px]">
          <span className="text-xs text-muted-foreground">Ratio:</span>
          <span className="text-sm font-mono font-medium text-primary">
            {compressionRatio.toFixed(1)}x
          </span>
        </div>

        <div className="flex-1 max-w-xs">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="text-muted-foreground">Context Usage</span>
            <span className="font-mono">
              {(tokensUsed / 1000).toFixed(1)}K / {(maxTokens / 1000).toFixed(0)}K
            </span>
          </div>
          <Progress value={usagePercent} className="h-1.5" />
        </div>

        <div className="flex items-center gap-1.5 text-green-600 dark:text-green-400">
          <TrendingUp className="h-3.5 w-3.5" />
          <span className="text-xs font-medium">
            {(tokensSaved / 1000).toFixed(1)}K saved
          </span>
        </div>
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6"
        onClick={() => setIsDismissed(true)}
        data-testid="button-dismiss-compression"
      >
        <X className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}
