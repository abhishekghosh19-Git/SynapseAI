import { useState } from "react";
import { Search, X, Check, BookOpen, Lightbulb } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import type { PromptTechnique } from "./PromptTechniqueBadge";

interface PromptTechniqueLibraryProps {
  isOpen: boolean;
  onClose: () => void;
  techniques: PromptTechnique[];
  selectedTechniques: PromptTechnique[];
  onTechniqueToggle: (technique: PromptTechnique) => void;
  onApply: () => void;
}

const categoryLabels: Record<string, string> = {
  reasoning: "Reasoning & Logic",
  retrieval: "Knowledge & Retrieval",
  refinement: "Output Refinement",
  framework: "Structured Frameworks",
  advanced: "Advanced Techniques",
};

const categoryDescriptions: Record<string, string> = {
  reasoning: "Step-by-step thinking and logical problem solving",
  retrieval: "External knowledge access and fact-checking",
  refinement: "Self-correction and output improvement",
  framework: "Pre-defined prompt structures and templates",
  advanced: "Cutting-edge meta-learning and optimization",
};

export default function PromptTechniqueLibrary({
  isOpen,
  onClose,
  techniques,
  selectedTechniques,
  onTechniqueToggle,
  onApply,
}: PromptTechniqueLibraryProps) {
  const [search, setSearch] = useState("");

  const filteredTechniques = techniques.filter(
    (t) =>
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.description.toLowerCase().includes(search.toLowerCase()) ||
      t.useCases.some((uc) => uc.toLowerCase().includes(search.toLowerCase()))
  );

  const groupedTechniques = filteredTechniques.reduce((acc, technique) => {
    if (!acc[technique.category]) {
      acc[technique.category] = [];
    }
    acc[technique.category].push(technique);
    return acc;
  }, {} as Record<string, PromptTechnique[]>);

  const isSelected = (id: string) => selectedTechniques.some((t) => t.id === id);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col p-0">
        <DialogHeader className="p-6 pb-4 border-b">
          <DialogTitle className="flex items-center gap-2 text-xl">
            <BookOpen className="h-5 w-5 text-primary" />
            Prompt Engineering Library
          </DialogTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Select techniques to enhance your prompts. Combine multiple for best results.
          </p>
        </DialogHeader>

        <div className="px-6 py-3 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search techniques, use cases..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-search-techniques"
            />
            {search && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-6 w-6"
                onClick={() => setSearch("")}
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>

          {selectedTechniques.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              <span className="text-xs text-muted-foreground self-center">Selected:</span>
              {selectedTechniques.map((technique) => (
                <Badge
                  key={technique.id}
                  variant="secondary"
                  className="gap-1 cursor-pointer"
                  onClick={() => onTechniqueToggle(technique)}
                >
                  {technique.shortName}
                  <X className="h-3 w-3" />
                </Badge>
              ))}
            </div>
          )}
        </div>

        <ScrollArea className="flex-1 px-6">
          <Accordion type="multiple" defaultValue={Object.keys(categoryLabels)} className="py-2">
            {Object.entries(groupedTechniques).map(([category, categoryTechniques]) => (
              <AccordionItem key={category} value={category}>
                <AccordionTrigger className="text-sm font-medium py-3">
                  <div className="flex items-center gap-2">
                    {categoryLabels[category]}
                    <Badge variant="outline" className="text-[10px] px-1.5">
                      {categoryTechniques.length}
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-xs text-muted-foreground mb-3">
                    {categoryDescriptions[category]}
                  </p>
                  <div className="space-y-2">
                    {categoryTechniques.map((technique) => {
                      const selected = isSelected(technique.id);
                      return (
                        <div
                          key={technique.id}
                          className={`
                            flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all
                            ${selected ? "border-primary bg-primary/5" : "hover:border-primary/50 hover:bg-muted/30"}
                          `}
                          onClick={() => onTechniqueToggle(technique)}
                          data-testid={`technique-card-${technique.id}`}
                        >
                          <div className={`
                            flex items-center justify-center h-5 w-5 rounded border flex-shrink-0 mt-0.5
                            ${selected ? "bg-primary border-primary text-primary-foreground" : "border-input"}
                          `}>
                            {selected && <Check className="h-3 w-3" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-medium text-sm">{technique.name}</span>
                              <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                                {technique.shortName}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              {technique.description}
                            </p>
                            <div className="flex items-center gap-1 mt-2 flex-wrap">
                              <Lightbulb className="h-3 w-3 text-muted-foreground" />
                              {technique.useCases.map((useCase) => (
                                <Badge key={useCase} variant="secondary" className="text-[10px] px-1.5 py-0">
                                  {useCase}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </ScrollArea>

        <div className="p-4 border-t flex items-center justify-between gap-4 bg-muted/30">
          <p className="text-sm text-muted-foreground">
            {selectedTechniques.length} technique{selectedTechniques.length !== 1 ? "s" : ""} selected
          </p>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} data-testid="button-cancel-techniques">
              Cancel
            </Button>
            <Button onClick={onApply} data-testid="button-apply-techniques">
              Apply Techniques
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
