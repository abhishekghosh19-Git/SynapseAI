import { useState } from "react";
import { Button } from "@/components/ui/button";
import PromptTechniqueLibrary from "../PromptTechniqueLibrary";
import type { PromptTechnique } from "../PromptTechniqueBadge";

// todo: remove mock functionality
const allTechniques: PromptTechnique[] = [
  {
    id: "cot",
    name: "Chain of Thought",
    shortName: "CoT",
    description: "Encourages step-by-step reasoning before answering, improving accuracy on complex problems.",
    category: "reasoning",
    useCases: ["Math problems", "Logic puzzles", "Multi-step analysis"],
  },
  {
    id: "react",
    name: "ReAct",
    shortName: "ReAct",
    description: "Combines reasoning with tool use for tasks requiring external information.",
    category: "reasoning",
    useCases: ["Research", "Fact-checking", "Data retrieval"],
  },
  {
    id: "tot",
    name: "Tree of Thoughts",
    shortName: "ToT",
    description: "Explores multiple reasoning branches before selecting the best path.",
    category: "reasoning",
    useCases: ["Creative writing", "Strategy planning", "Complex decisions"],
  },
  {
    id: "self-consistency",
    name: "Self-Consistency",
    shortName: "SC",
    description: "Generates multiple answers and selects the most consistent one.",
    category: "reasoning",
    useCases: ["Math verification", "Critical decisions", "Fact validation"],
  },
  {
    id: "rag",
    name: "Retrieval Augmented",
    shortName: "RAG",
    description: "Retrieves relevant external knowledge before generating responses.",
    category: "retrieval",
    useCases: ["Documentation", "Knowledge bases", "Current events"],
  },
  {
    id: "semantic-search",
    name: "Semantic Search",
    shortName: "SemSearch",
    description: "Uses embeddings to find semantically similar content.",
    category: "retrieval",
    useCases: ["Document search", "Similar content", "Topic clustering"],
  },
  {
    id: "reflexion",
    name: "Reflexion",
    shortName: "Reflexion",
    description: "Model evaluates and critiques its own output for improvement.",
    category: "refinement",
    useCases: ["Code review", "Essay writing", "Quality assurance"],
  },
  {
    id: "self-refine",
    name: "Self-Refine",
    shortName: "SelfRef",
    description: "Iteratively improves responses through self-feedback loops.",
    category: "refinement",
    useCases: ["Polish outputs", "Error correction", "Style improvement"],
  },
  {
    id: "costar",
    name: "COSTAR Framework",
    shortName: "COSTAR",
    description: "Context, Objective, Style, Tone, Audience, Response structure.",
    category: "framework",
    useCases: ["Business writing", "Content creation", "Structured tasks"],
  },
  {
    id: "persona",
    name: "Persona Pattern",
    shortName: "Persona",
    description: "Assigns a specific role or expertise to the AI.",
    category: "framework",
    useCases: ["Expert advice", "Role-playing", "Specialized knowledge"],
  },
  {
    id: "mdp",
    name: "MDP Agent",
    shortName: "MDP",
    description: "Uses Markov Decision Process for optimal action selection.",
    category: "advanced",
    useCases: ["Sequential decisions", "Planning", "Game playing"],
  },
  {
    id: "meta-learning",
    name: "Meta-Learning",
    shortName: "MetaL",
    description: "Learns to optimize its own learning process over time.",
    category: "advanced",
    useCases: ["Self-improvement", "Adaptation", "Pattern recognition"],
  },
];

export default function PromptTechniqueLibraryExample() {
  const [isOpen, setIsOpen] = useState(false);
  const [selected, setSelected] = useState<PromptTechnique[]>([allTechniques[0]]);

  const handleToggle = (technique: PromptTechnique) => {
    setSelected((prev) =>
      prev.some((t) => t.id === technique.id)
        ? prev.filter((t) => t.id !== technique.id)
        : [...prev, technique]
    );
  };

  return (
    <>
      <Button onClick={() => setIsOpen(true)} data-testid="button-open-library">
        Open Prompt Library ({selected.length} selected)
      </Button>
      <PromptTechniqueLibrary
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        techniques={allTechniques}
        selectedTechniques={selected}
        onTechniqueToggle={handleToggle}
        onApply={() => {
          console.log("Applied:", selected);
          setIsOpen(false);
        }}
      />
    </>
  );
}
