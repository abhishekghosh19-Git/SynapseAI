import { useState, useRef, useEffect } from "react";
import { RefreshCw, ExternalLink, Smartphone, Monitor, Tablet, Loader2, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type DeviceMode = "desktop" | "tablet" | "mobile";

interface LivePreviewProps {
  htmlContent?: string;
  url?: string;
  isLoading?: boolean;
  error?: string;
  onRefresh?: () => void;
}

const deviceSizes: Record<DeviceMode, { width: number; label: string }> = {
  desktop: { width: 1024, label: "Desktop" },
  tablet: { width: 768, label: "Tablet" },
  mobile: { width: 375, label: "Mobile" },
};

export default function LivePreview({
  htmlContent,
  url,
  isLoading = false,
  error,
  onRefresh,
}: LivePreviewProps) {
  const [deviceMode, setDeviceMode] = useState<DeviceMode>("desktop");
  const [isIframeLoading, setIsIframeLoading] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (iframeRef.current && htmlContent) {
      const doc = iframeRef.current.contentDocument;
      if (doc) {
        doc.open();
        doc.write(htmlContent);
        doc.close();
      }
    }
  }, [htmlContent]);

  const handleRefresh = () => {
    if (url && iframeRef.current) {
      setIsIframeLoading(true);
      iframeRef.current.src = url;
    }
    onRefresh?.();
  };

  const openInNewTab = () => {
    if (url) {
      window.open(url, "_blank");
    } else if (htmlContent) {
      const blob = new Blob([htmlContent], { type: "text/html" });
      const blobUrl = URL.createObjectURL(blob);
      window.open(blobUrl, "_blank");
    }
  };

  return (
    <div className="flex flex-col h-full border rounded-lg overflow-hidden bg-card">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 border-b bg-muted/30">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs gap-1.5">
            {isLoading || isIframeLoading ? (
              <>
                <Loader2 className="h-3 w-3 animate-spin" />
                Loading...
              </>
            ) : error ? (
              <>
                <X className="h-3 w-3 text-destructive" />
                Error
              </>
            ) : (
              <>
                <Check className="h-3 w-3 text-green-500" />
                Live
              </>
            )}
          </Badge>
        </div>

        <div className="flex items-center gap-1">
          {/* Device toggles */}
          <div className="flex items-center border rounded-md p-0.5 bg-muted/50">
            <Button
              variant={deviceMode === "mobile" ? "secondary" : "ghost"}
              size="icon"
              className="h-6 w-6"
              onClick={() => setDeviceMode("mobile")}
              data-testid="button-device-mobile"
            >
              <Smartphone className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant={deviceMode === "tablet" ? "secondary" : "ghost"}
              size="icon"
              className="h-6 w-6"
              onClick={() => setDeviceMode("tablet")}
              data-testid="button-device-tablet"
            >
              <Tablet className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant={deviceMode === "desktop" ? "secondary" : "ghost"}
              size="icon"
              className="h-6 w-6"
              onClick={() => setDeviceMode("desktop")}
              data-testid="button-device-desktop"
            >
              <Monitor className="h-3.5 w-3.5" />
            </Button>
          </div>

          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleRefresh} data-testid="button-refresh-preview">
            <RefreshCw className={`h-3.5 w-3.5 ${isIframeLoading ? "animate-spin" : ""}`} />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={openInNewTab} data-testid="button-open-external">
            <ExternalLink className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {/* Preview area */}
      <div className="flex-1 flex items-start justify-center bg-muted/10 p-4 overflow-auto">
        {error ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
              <X className="h-6 w-6 text-destructive" />
            </div>
            <h3 className="text-lg font-medium mb-2">Preview Error</h3>
            <p className="text-sm text-muted-foreground max-w-md">{error}</p>
          </div>
        ) : isLoading ? (
          <div className="flex flex-col items-center justify-center h-full">
            <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
            <p className="text-sm text-muted-foreground">Generating preview...</p>
          </div>
        ) : (
          <div
            className="bg-white rounded-lg shadow-lg overflow-hidden transition-all duration-300"
            style={{
              width: deviceMode === "desktop" ? "100%" : deviceSizes[deviceMode].width,
              maxWidth: deviceSizes[deviceMode].width,
              height: deviceMode === "mobile" ? "667px" : "100%",
              minHeight: "400px",
            }}
          >
            <iframe
              ref={iframeRef}
              src={url}
              className="w-full h-full border-0"
              title="Live Preview"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
              onLoad={() => setIsIframeLoading(false)}
              data-testid="iframe-preview"
            />
          </div>
        )}
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 py-1 border-t bg-muted/30 text-xs text-muted-foreground">
        <span>{deviceSizes[deviceMode].label} - {deviceSizes[deviceMode].width}px</span>
        {url && <span className="truncate max-w-xs">{url}</span>}
      </div>
    </div>
  );
}
