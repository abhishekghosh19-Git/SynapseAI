import { useState } from "react";
import { GitBranch, ArrowRight, Circle, CheckCircle2, Loader2, AlertCircle, Play, Pause, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

export type NodeStatus = "pending" | "running" | "completed" | "error" | "skipped";

export interface FlowNode {
  id: string;
  label: string;
  description?: string;
  type: "input" | "process" | "decision" | "output" | "agent";
  status: NodeStatus;
  duration?: number;
  children?: string[];
  dependencies?: string[];
}

interface SystemsThinkingFlowProps {
  nodes: FlowNode[];
  title?: string;
  isRunning?: boolean;
  onStart?: () => void;
  onPause?: () => void;
  onReset?: () => void;
  onNodeClick?: (id: string) => void;
}

const statusIcons: Record<NodeStatus, typeof Circle> = {
  pending: Circle,
  running: Loader2,
  completed: CheckCircle2,
  error: AlertCircle,
  skipped: Circle,
};

const statusColors: Record<NodeStatus, string> = {
  pending: "text-muted-foreground border-muted",
  running: "text-primary border-primary animate-pulse",
  completed: "text-green-500 border-green-500",
  error: "text-destructive border-destructive",
  skipped: "text-muted-foreground/50 border-muted/50",
};

const typeColors: Record<string, string> = {
  input: "bg-blue-500/10 dark:bg-blue-500/20",
  process: "bg-violet-500/10 dark:bg-violet-500/20",
  decision: "bg-amber-500/10 dark:bg-amber-500/20",
  output: "bg-green-500/10 dark:bg-green-500/20",
  agent: "bg-cyan-500/10 dark:bg-cyan-500/20",
};

export default function SystemsThinkingFlow({
  nodes,
  title = "Systems Flow",
  isRunning = false,
  onStart,
  onPause,
  onReset,
  onNodeClick,
}: SystemsThinkingFlowProps) {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);

  const handleNodeClick = (id: string) => {
    setSelectedNode(id);
    onNodeClick?.(id);
  };

  const completedCount = nodes.filter((n) => n.status === "completed").length;
  const progress = (completedCount / nodes.length) * 100;

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <GitBranch className="h-4 w-4 text-primary" />
            {title}
          </CardTitle>
          <div className="flex items-center gap-2">
            {onReset && (
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onReset} data-testid="button-reset-flow">
                <RotateCcw className="h-3.5 w-3.5" />
              </Button>
            )}
            {(onStart || onPause) && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 gap-1.5"
                onClick={isRunning ? onPause : onStart}
                data-testid="button-toggle-flow"
              >
                {isRunning ? (
                  <>
                    <Pause className="h-3.5 w-3.5" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="h-3.5 w-3.5" />
                    Start
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="mt-3">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
            <span>{completedCount} / {nodes.length} steps</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-300 rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 min-h-0 p-3">
        <ScrollArea className="h-full">
          <div className="space-y-2 pr-2">
            {nodes.map((node, index) => {
              const StatusIcon = statusIcons[node.status];
              const isSelected = selectedNode === node.id;
              
              return (
                <div key={node.id} className="relative">
                  {/* Connection line */}
                  {index > 0 && (
                    <div className="absolute left-4 -top-2 h-2 w-px bg-border" />
                  )}
                  
                  <div
                    className={`
                      flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all
                      ${typeColors[node.type]}
                      ${isSelected ? "ring-2 ring-primary" : "hover:ring-1 hover:ring-primary/50"}
                      ${statusColors[node.status]}
                    `}
                    onClick={() => handleNodeClick(node.id)}
                    data-testid={`flow-node-${node.id}`}
                  >
                    <div className={`mt-0.5 ${node.status === "running" ? "animate-spin" : ""}`}>
                      <StatusIcon className={`h-4 w-4 ${statusColors[node.status].split(" ")[0]}`} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium">{node.label}</span>
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 capitalize">
                          {node.type}
                        </Badge>
                        {node.duration && (
                          <span className="text-[10px] text-muted-foreground">
                            {node.duration}ms
                          </span>
                        )}
                      </div>
                      {node.description && (
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                          {node.description}
                        </p>
                      )}
                    </div>
                    
                    {node.children && node.children.length > 0 && (
                      <ArrowRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
