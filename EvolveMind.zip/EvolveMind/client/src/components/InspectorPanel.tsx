import { useState } from "react";
import { X, GitBranch, BarChart3, Database, Settings2, Zap, Brain, Gauge, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import ReasoningStep, { type ReasoningStepData } from "./ReasoningStep";
import PerformanceMetric, { type MetricData } from "./PerformanceMetric";

interface InspectorPanelProps {
  isOpen: boolean;
  onClose: () => void;
  reasoningTree: ReasoningStepData | null;
  metrics: MetricData[];
  memorySlots: { id: string; label: string; tokens: number; similarity: number }[];
  settings: {
    epsilon: number;
    compressionThreshold: number;
    selfReflectionDepth: number;
    metaLearningEnabled: boolean;
    goldenRatioOptimization: boolean;
  };
  onSettingsChange: (key: string, value: number | boolean) => void;
}

export default function InspectorPanel({
  isOpen,
  onClose,
  reasoningTree,
  metrics,
  memorySlots,
  settings,
  onSettingsChange,
}: InspectorPanelProps) {
  const [activeTab, setActiveTab] = useState("reasoning");

  if (!isOpen) return null;

  return (
    <div className="w-[360px] border-l border-border bg-background flex flex-col h-full">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="font-semibold">Inspector</h2>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={onClose}
          data-testid="button-close-inspector"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
        <TabsList className="grid grid-cols-4 mx-4 mt-2">
          <TabsTrigger value="reasoning" className="text-xs gap-1" data-testid="tab-reasoning">
            <GitBranch className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Tree</span>
          </TabsTrigger>
          <TabsTrigger value="analytics" className="text-xs gap-1" data-testid="tab-analytics">
            <BarChart3 className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Stats</span>
          </TabsTrigger>
          <TabsTrigger value="memory" className="text-xs gap-1" data-testid="tab-memory">
            <Database className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Memory</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="text-xs gap-1" data-testid="tab-settings">
            <Settings2 className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Config</span>
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1 p-4">
          <TabsContent value="reasoning" className="mt-0">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <GitBranch className="h-4 w-4 text-primary" />
                  Reasoning Tree
                </CardTitle>
              </CardHeader>
              <CardContent className="p-2">
                {reasoningTree ? (
                  <ReasoningStep step={reasoningTree} />
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    No active reasoning process
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="mt-0 space-y-3">
            {metrics.map((metric, index) => (
              <PerformanceMetric
                key={metric.label}
                metric={metric}
                icon={
                  index === 0 ? <Zap className="h-5 w-5" /> :
                  index === 1 ? <Database className="h-5 w-5" /> :
                  index === 2 ? <Brain className="h-5 w-5" /> :
                  <Gauge className="h-5 w-5" />
                }
              />
            ))}

            <Card className="mt-4">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" />
                  Session Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-20 flex items-end gap-1">
                  {Array.from({ length: 20 }).map((_, i) => (
                    <div
                      key={i}
                      className="flex-1 bg-primary/20 rounded-t"
                      style={{ height: `${Math.random() * 100}%` }}
                    />
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground text-center mt-2">
                  Token usage over time
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="memory" className="mt-0">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Database className="h-4 w-4 text-primary" />
                  Semantic Memory Slots
                </CardTitle>
              </CardHeader>
              <CardContent className="p-2">
                <div className="space-y-2">
                  {memorySlots.map((slot) => (
                    <div
                      key={slot.id}
                      className="flex items-center justify-between p-2 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{slot.label}</p>
                        <p className="text-xs text-muted-foreground">
                          {slot.tokens} tokens
                        </p>
                      </div>
                      <Badge
                        variant={slot.similarity > 0.8 ? "default" : "secondary"}
                        className="text-[10px] ml-2"
                      >
                        {(slot.similarity * 100).toFixed(0)}% match
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="mt-0 space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Agent Parameters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm">Exploration Rate (e)</Label>
                    <span className="text-xs font-mono text-muted-foreground">
                      {settings.epsilon.toFixed(2)}
                    </span>
                  </div>
                  <Slider
                    value={[settings.epsilon * 100]}
                    max={100}
                    step={1}
                    onValueChange={([val]) => onSettingsChange("epsilon", val / 100)}
                    data-testid="slider-epsilon"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Balance between exploring new strategies vs exploiting known good ones
                  </p>
                </div>

                <Separator />

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm">Compression Threshold</Label>
                    <span className="text-xs font-mono text-muted-foreground">
                      {settings.compressionThreshold}%
                    </span>
                  </div>
                  <Slider
                    value={[settings.compressionThreshold]}
                    max={100}
                    step={5}
                    onValueChange={([val]) => onSettingsChange("compressionThreshold", val)}
                    data-testid="slider-compression"
                  />
                </div>

                <Separator />

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm">Self-Reflection Depth</Label>
                    <span className="text-xs font-mono text-muted-foreground">
                      {settings.selfReflectionDepth}
                    </span>
                  </div>
                  <Slider
                    value={[settings.selfReflectionDepth]}
                    min={1}
                    max={5}
                    step={1}
                    onValueChange={([val]) => onSettingsChange("selfReflectionDepth", val)}
                    data-testid="slider-reflection"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm">Meta-Learning</Label>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      Learn from conversation patterns
                    </p>
                  </div>
                  <Switch
                    checked={settings.metaLearningEnabled}
                    onCheckedChange={(val) => onSettingsChange("metaLearningEnabled", val)}
                    data-testid="switch-metalearning"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm">Golden Ratio Optimization</Label>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      Use f = 1.618 for learning rates
                    </p>
                  </div>
                  <Switch
                    checked={settings.goldenRatioOptimization}
                    onCheckedChange={(val) => onSettingsChange("goldenRatioOptimization", val)}
                    data-testid="switch-goldenratio"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}
