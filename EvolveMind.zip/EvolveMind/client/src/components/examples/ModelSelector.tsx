import { useState } from "react";
import ModelSelector, { type AIModel } from "../ModelSelector";

// todo: remove mock functionality
const mockModels: AIModel[] = [
  {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash",
    provider: "Google",
    description: "Fast, free, 1M token context",
    isFree: true,
    icon: "zap",
  },
  {
    id: "llama-3.3-70b",
    name: "Llama 3.3 70B",
    provider: "Groq",
    description: "Ultra-fast inference",
    isFree: true,
    icon: "brain",
  },
  {
    id: "gpt-4o",
    name: "GPT-4o",
    provider: "OpenAI",
    description: "Most capable model",
    isFree: false,
    icon: "sparkles",
  },
  {
    id: "deepseek-v3",
    name: "DeepSeek V3",
    provider: "OpenRouter",
    description: "Cost-efficient, 128K context",
    isFree: true,
    icon: "globe",
  },
];

export default function ModelSelectorExample() {
  const [selectedModel, setSelectedModel] = useState(mockModels[0]);

  return (
    <div className="w-64">
      <ModelSelector
        models={mockModels}
        selectedModel={selectedModel}
        onModelChange={setSelectedModel}
      />
    </div>
  );
}
