import { useState } from "react";
import InputComposer from "../InputComposer";
import type { PromptTechnique } from "../PromptTechniqueBadge";

// todo: remove mock functionality
const mockTechniques: PromptTechnique[] = [
  {
    id: "cot",
    name: "Chain of Thought",
    shortName: "CoT",
    description: "Step-by-step reasoning",
    category: "reasoning",
    useCases: ["Math", "Logic"],
  },
  {
    id: "react",
    name: "ReAct",
    shortName: "ReAct",
    description: "Reasoning + Acting",
    category: "reasoning",
    useCases: ["Research", "Tools"],
  },
];

export default function InputComposerExample() {
  const [techniques, setTechniques] = useState<PromptTechnique[]>(mockTechniques);
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = (message: string, activeTechniques: PromptTechnique[]) => {
    console.log("Sending:", message, "with techniques:", activeTechniques);
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 2000);
  };

  return (
    <div className="w-full max-w-2xl border rounded-lg overflow-hidden">
      <InputComposer
        onSend={handleSend}
        isLoading={isLoading}
        activeTechniques={techniques}
        onTechniqueRemove={(id) => setTechniques((prev) => prev.filter((t) => t.id !== id))}
        onOpenTechniqueLibrary={() => console.log("Opening technique library...")}
      />
    </div>
  );
}
