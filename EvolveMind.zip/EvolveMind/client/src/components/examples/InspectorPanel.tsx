import { useState } from "react";
import { Button } from "@/components/ui/button";
import InspectorPanel from "../InspectorPanel";
import type { ReasoningStepData } from "../ReasoningStep";
import type { MetricData } from "../PerformanceMetric";

// todo: remove mock functionality
const mockReasoningTree: ReasoningStepData = {
  id: "1",
  type: "thought",
  content: "Analyzing the user's request to break it down into steps.",
  status: "complete",
  duration: 120,
  children: [
    {
      id: "2",
      type: "action",
      content: "Searching knowledge base for relevant information.",
      status: "complete",
      tool: "RAG",
      duration: 450,
    },
    {
      id: "3",
      type: "observation",
      content: "Found 3 relevant documents with 89% similarity.",
      status: "complete",
      duration: 30,
    },
  ],
};

const mockMetrics: MetricData[] = [
  { label: "Token Efficiency", value: "87.3", unit: "%", trend: "up", trendValue: "+5.2%" },
  { label: "Context Used", value: "24.5K", unit: "/ 128K", trend: "neutral" },
  { label: "Learning Rate", value: "0.618", trend: "up", trendValue: "+0.02" },
  { label: "Explore/Exploit", value: "32/68", unit: "%", trend: "down", trendValue: "-3%" },
];

const mockMemorySlots = [
  { id: "1", label: "Chain of Thought patterns", tokens: 1250, similarity: 0.92 },
  { id: "2", label: "Previous context summary", tokens: 890, similarity: 0.85 },
  { id: "3", label: "Tool usage history", tokens: 450, similarity: 0.78 },
  { id: "4", label: "User preferences", tokens: 320, similarity: 0.71 },
];

export default function InspectorPanelExample() {
  const [isOpen, setIsOpen] = useState(true);
  const [settings, setSettings] = useState({
    epsilon: 0.32,
    compressionThreshold: 75,
    selfReflectionDepth: 2,
    metaLearningEnabled: true,
    goldenRatioOptimization: true,
  });

  return (
    <div className="flex h-[600px] border rounded-lg overflow-hidden">
      <div className="flex-1 flex items-center justify-center bg-muted/30">
        <Button onClick={() => setIsOpen(true)}>Open Inspector</Button>
      </div>
      <InspectorPanel
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        reasoningTree={mockReasoningTree}
        metrics={mockMetrics}
        memorySlots={mockMemorySlots}
        settings={settings}
        onSettingsChange={(key, value) =>
          setSettings((prev) => ({ ...prev, [key]: value }))
        }
      />
    </div>
  );
}
