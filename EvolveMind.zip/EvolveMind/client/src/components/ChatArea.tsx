import { useRef, useEffect } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import MessageBubble, { type Message } from "./MessageBubble";
import InputComposer from "./InputComposer";
import TypingIndicator from "./TypingIndicator";
import CompressionIndicator from "./CompressionIndicator";
import type { PromptTechnique } from "./PromptTechniqueBadge";
import { MessageSquarePlus } from "lucide-react";

interface ChatAreaProps {
  messages: Message[];
  isLoading: boolean;
  activeTechniques: PromptTechnique[];
  onTechniqueRemove: (id: string) => void;
  onOpenTechniqueLibrary: () => void;
  onSendMessage: (message: string, techniques: PromptTechnique[]) => void;
  onCopyMessage: (id: string) => void;
  onRegenerateMessage: (id: string) => void;
  onFeedback: (id: string, type: "up" | "down") => void;
  modelName?: string;
  compressionStats?: {
    ratio: number;
    tokensUsed: number;
    maxTokens: number;
    tokensSaved: number;
  };
}

export default function ChatArea({
  messages,
  isLoading,
  activeTechniques,
  onTechniqueRemove,
  onOpenTechniqueLibrary,
  onSendMessage,
  onCopyMessage,
  onRegenerateMessage,
  onFeedback,
  modelName,
  compressionStats,
}: ChatAreaProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  return (
    <div className="flex flex-col h-full bg-background">
      {compressionStats && (
        <CompressionIndicator
          compressionRatio={compressionStats.ratio}
          tokensUsed={compressionStats.tokensUsed}
          maxTokens={compressionStats.maxTokens}
          tokensSaved={compressionStats.tokensSaved}
        />
      )}

      <ScrollArea className="flex-1 p-6" ref={scrollRef}>
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-12">
            <div className="flex items-center justify-center h-16 w-16 rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 mb-4">
              <MessageSquarePlus className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Start a New Conversation</h2>
            <p className="text-muted-foreground max-w-md mb-6">
              Ask me anything! I use advanced prompting techniques like Chain of Thought, 
              ReAct, and self-reflection to provide thoughtful, accurate responses.
            </p>
            <div className="flex flex-wrap gap-2 justify-center max-w-lg">
              {[
                "Explain quantum computing step by step",
                "Help me debug this code",
                "Research the latest AI trends",
                "Write a business proposal",
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  className="px-3 py-2 text-sm border rounded-lg hover:bg-muted transition-colors text-left"
                  onClick={() => onSendMessage(suggestion, activeTechniques)}
                  data-testid="button-suggestion"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-6 max-w-3xl mx-auto">
            {messages.map((message) => (
              <MessageBubble
                key={message.id}
                message={message}
                onCopy={() => onCopyMessage(message.id)}
                onRegenerate={() => onRegenerateMessage(message.id)}
                onFeedback={(type) => onFeedback(message.id, type)}
              />
            ))}
            {isLoading && <TypingIndicator modelName={modelName} />}
          </div>
        )}
      </ScrollArea>

      <InputComposer
        onSend={onSendMessage}
        isLoading={isLoading}
        activeTechniques={activeTechniques}
        onTechniqueRemove={onTechniqueRemove}
        onOpenTechniqueLibrary={onOpenTechniqueLibrary}
      />
    </div>
  );
}
