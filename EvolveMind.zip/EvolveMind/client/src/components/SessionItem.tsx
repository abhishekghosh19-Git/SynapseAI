import { MessageSquare, MoreVertical, Trash2, Pencil, Archive } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export interface Session {
  id: string;
  title: string;
  preview: string;
  messageCount: number;
  updatedAt: Date;
  model?: string;
}

interface SessionItemProps {
  session: Session;
  isActive: boolean;
  onClick: () => void;
  onRename: () => void;
  onArchive: () => void;
  onDelete: () => void;
}

export default function SessionItem({
  session,
  isActive,
  onClick,
  onRename,
  onArchive,
  onDelete,
}: SessionItemProps) {
  const formatDate = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) return "Today";
    if (days === 1) return "Yesterday";
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  };

  return (
    <div
      className={`
        group relative flex items-start gap-2 p-2 rounded-lg cursor-pointer
        transition-colors
        ${isActive ? "bg-sidebar-accent" : "hover:bg-sidebar-accent/50"}
      `}
      onClick={onClick}
      data-testid={`session-${session.id}`}
    >
      <MessageSquare className="h-4 w-4 mt-1 text-muted-foreground flex-shrink-0" />

      <div className="flex-1 min-w-0 overflow-hidden">
        <div className="flex items-center justify-between gap-2">
          <h4 className="text-sm font-medium truncate">{session.title}</h4>
          <span className="text-[10px] text-muted-foreground flex-shrink-0">
            {formatDate(session.updatedAt)}
          </span>
        </div>
        <p className="text-xs text-muted-foreground truncate mt-0.5">
          {session.preview}
        </p>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-[10px] text-muted-foreground">
            {session.messageCount} messages
          </span>
          {session.model && (
            <span className="text-[10px] text-primary font-medium">
              {session.model}
            </span>
          )}
        </div>
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0"
            onClick={(e) => e.stopPropagation()}
            data-testid="button-session-menu"
          >
            <MoreVertical className="h-3.5 w-3.5" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-40">
          <DropdownMenuItem onClick={onRename} data-testid="menu-item-rename">
            <Pencil className="h-3.5 w-3.5 mr-2" />
            Rename
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onArchive} data-testid="menu-item-archive">
            <Archive className="h-3.5 w-3.5 mr-2" />
            Archive
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onClick={onDelete}
            className="text-destructive focus:text-destructive"
            data-testid="menu-item-delete"
          >
            <Trash2 className="h-3.5 w-3.5 mr-2" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
