import ReasoningStep, { type ReasoningStepData } from "../ReasoningStep";

// todo: remove mock functionality
const mockReasoningTree: ReasoningStepData = {
  id: "1",
  type: "thought",
  content: "I need to break down this math problem step by step to find the solution.",
  status: "complete",
  duration: 120,
  children: [
    {
      id: "2",
      type: "action",
      content: "Calculate the first part of the equation: 15 * 4 = 60",
      status: "complete",
      tool: "Calculator",
      duration: 45,
    },
    {
      id: "3",
      type: "observation",
      content: "The first calculation gives us 60. Now I need to add the second part.",
      status: "complete",
      duration: 30,
    },
    {
      id: "4",
      type: "action",
      content: "Searching for relevant formulas in the knowledge base...",
      status: "running",
      tool: "Search",
      children: [
        {
          id: "5",
          type: "thought",
          content: "Found 3 relevant documents about quadratic equations.",
          status: "pending",
        },
      ],
    },
  ],
};

export default function ReasoningStepExample() {
  return (
    <div className="w-full max-w-lg border rounded-lg p-2 bg-card">
      <h3 className="text-sm font-medium mb-2 px-2">Reasoning Tree</h3>
      <ReasoningStep step={mockReasoningTree} />
    </div>
  );
}
