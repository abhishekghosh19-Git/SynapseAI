import { ThemeProvider } from "@/context/ThemeContext";
import ThemeToggle from "../ThemeToggle";

export default function ThemeToggleExample() {
  return (
    <ThemeProvider>
      <div className="flex items-center gap-3">
        <ThemeToggle />
        <span className="text-sm text-muted-foreground">Click to toggle theme</span>
      </div>
    </ThemeProvider>
  );
}
