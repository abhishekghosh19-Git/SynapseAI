import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Sessions for conversation history
export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  preview: text("preview"),
  model: text("model").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// Messages within sessions
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull(),
  role: text("role").notNull(), // 'user' | 'assistant' | 'system'
  content: text("content").notNull(),
  model: text("model"),
  tokenCount: integer("token_count"),
  techniques: text("techniques").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Generated files and code
export const generatedFiles = pgTable("generated_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull(),
  name: text("name").notNull(),
  language: text("language").notNull(),
  content: text("content").notNull(),
  version: integer("version").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertGeneratedFileSchema = createInsertSchema(generatedFiles).omit({ id: true, createdAt: true, updatedAt: true, version: true });
export type InsertGeneratedFile = z.infer<typeof insertGeneratedFileSchema>;
export type GeneratedFile = typeof generatedFiles.$inferSelect;

// Agent configurations
export const agents = pgTable("agents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  systemPrompt: text("system_prompt").notNull(),
  capabilities: jsonb("capabilities").notNull(),
  maxIterations: integer("max_iterations").default(10).notNull(),
  autoExecute: boolean("auto_execute").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAgentSchema = createInsertSchema(agents).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Agent = typeof agents.$inferSelect;

// Type definitions for frontend use
export interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  isFree: boolean;
  icon: "zap" | "brain" | "sparkles" | "globe";
}

export interface PromptTechnique {
  id: string;
  name: string;
  shortName: string;
  description: string;
  category: "reasoning" | "retrieval" | "refinement" | "framework" | "advanced";
  useCases: string[];
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  model?: string;
  tokenCount?: number;
  techniques?: string[];
}

export interface AgentCapability {
  id: string;
  name: string;
  description: string;
  icon: "zap" | "brain" | "globe" | "wrench";
  enabled: boolean;
}

export interface AgentConfig {
  name: string;
  description: string;
  systemPrompt: string;
  capabilities: AgentCapability[];
  maxIterations: number;
  autoExecute: boolean;
}

export interface CodeFile {
  id: string;
  name: string;
  language: string;
  content: string;
  isModified?: boolean;
  version?: number;
}

export interface FlowNode {
  id: string;
  label: string;
  description?: string;
  type: "input" | "process" | "decision" | "output" | "agent";
  status: "pending" | "running" | "completed" | "error" | "skipped";
  duration?: number;
  children?: string[];
  dependencies?: string[];
}
