import TypingIndicator from "../TypingIndicator";

export default function TypingIndicatorExample() {
  return <TypingIndicator modelName="Gemini 2.5 Flash" />;
}
