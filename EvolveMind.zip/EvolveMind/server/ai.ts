import { GoogleGenAI } from "@google/genai";
import OpenAI from "openai";

// Multi-model AI service supporting Gemini, OpenAI, and Groq
const geminiClient = process.env.GEMINI_API_KEY 
  ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
  : null;

const openaiClient = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const groqClient = process.env.GROQ_API_KEY
  ? new OpenAI({ 
      apiKey: process.env.GROQ_API_KEY,
      baseURL: "https://api.groq.com/openai/v1"
    })
  : null;

export interface ChatRequest {
  message: string;
  techniques?: string[];
  model?: string;
  systemPrompt?: string;
  context?: { role: string; content: string }[];
}

export interface ChatResponse {
  content: string;
  tokenCount?: number;
  model: string;
}

export interface CodeGenerationRequest {
  prompt: string;
  language?: string;
  framework?: string;
}

export interface CodeGenerationResponse {
  files: {
    name: string;
    language: string;
    content: string;
  }[];
  explanation: string;
}

// Model configurations
const modelConfigs: Record<string, { provider: "gemini" | "openai" | "groq"; modelId: string }> = {
  "gemini-2.5-flash": { provider: "gemini", modelId: "gemini-2.5-flash" },
  "gemini-2.5-pro": { provider: "gemini", modelId: "gemini-2.5-pro" },
  "gpt-4o": { provider: "openai", modelId: "gpt-4o" },
  "gpt-4o-mini": { provider: "openai", modelId: "gpt-4o-mini" },
  "llama-3.3-70b": { provider: "groq", modelId: "llama-3.3-70b-versatile" },
  "llama-3.1-8b": { provider: "groq", modelId: "llama-3.1-8b-instant" },
  "deepseek-v3": { provider: "groq", modelId: "deepseek-r1-distill-llama-70b" },
};

// Build system prompt based on selected techniques
function buildSystemPrompt(techniques: string[]): string {
  const techniqueMappings: Record<string, string> = {
    cot: "Think step-by-step. Before answering, break down your reasoning process into clear, numbered steps. Show your work.",
    react: "Use a Reason-Act-Observe pattern. For each step: 1) THOUGHT: reason about what to do, 2) ACTION: describe what action to take, 3) OBSERVATION: note the result.",
    tot: "Explore multiple reasoning branches. Consider 2-3 different approaches to solve this problem, evaluate each, then select the best one.",
    "self-consistency": "Generate your answer, then verify it by approaching the problem from a different angle. Only provide the answer if both approaches agree.",
    rag: "If you need external information, acknowledge what you know and what would need to be retrieved from external sources.",
    reflexion: "After generating your response, self-critique it. Identify potential issues or improvements, then provide an improved version.",
    costar: "Structure your response using: Context (understand the situation), Objective (the goal), Style (appropriate tone), Tone (emotional register), Audience (who you're addressing), Response (the actual answer).",
    persona: "You are an expert with deep knowledge in the relevant domain. Draw on your expertise to provide authoritative, well-reasoned answers.",
    mdp: "Model this as a decision process. Consider: current state, available actions, transition probabilities, and expected rewards to determine optimal actions.",
    "meta-learning": "Before answering, consider: What type of problem is this? What strategies work best for this type? How can I adapt my approach based on past similar problems?",
  };

  const basePrompt = `You are SynapseAI, an advanced AI assistant that helps users build applications, create agents, and solve complex problems. You provide clear, accurate, and helpful responses.`;

  if (!techniques || techniques.length === 0) {
    return basePrompt;
  }

  const techniqueInstructions = techniques
    .map(t => techniqueMappings[t])
    .filter(Boolean)
    .join("\n\n");

  return `${basePrompt}\n\n## Applied Techniques\n${techniqueInstructions}`;
}

// Call Gemini API
async function callGemini(request: ChatRequest, modelId: string): Promise<ChatResponse> {
  if (!geminiClient) {
    throw new Error("Gemini API not configured");
  }

  const systemPrompt = request.systemPrompt || buildSystemPrompt(request.techniques || []);
  const messages = [
    ...(request.context || []).map(msg => ({
      role: msg.role === "assistant" ? "model" as const : "user" as const,
      parts: [{ text: msg.content }]
    })),
    { role: "user" as const, parts: [{ text: request.message }] }
  ];

  const response = await geminiClient.models.generateContent({
    model: modelId,
    config: {
      systemInstruction: systemPrompt,
      temperature: 0.7,
      maxOutputTokens: 4096,
    },
    contents: messages,
  });

  const text = response.text || "I apologize, but I couldn't generate a response. Please try again.";
  const tokenCount = Math.ceil((request.message.length + text.length) / 4);

  return { content: text, tokenCount, model: modelId };
}

// Call OpenAI-compatible API (OpenAI or Groq)
async function callOpenAI(
  client: OpenAI,
  request: ChatRequest,
  modelId: string
): Promise<ChatResponse> {
  const systemPrompt = request.systemPrompt || buildSystemPrompt(request.techniques || []);
  
  const messages: OpenAI.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    ...(request.context || []).map(msg => ({
      role: msg.role as "user" | "assistant",
      content: msg.content,
    })),
    { role: "user", content: request.message },
  ];

  const response = await client.chat.completions.create({
    model: modelId,
    messages,
    temperature: 0.7,
    max_tokens: 4096,
  });

  const text = response.choices[0]?.message?.content || "I apologize, but I couldn't generate a response.";
  const tokenCount = response.usage?.total_tokens || Math.ceil((request.message.length + text.length) / 4);

  return { content: text, tokenCount, model: modelId };
}

export async function chat(request: ChatRequest): Promise<ChatResponse> {
  const modelKey = request.model || "gemini-2.5-flash";
  const config = modelConfigs[modelKey];
  
  if (!config) {
    // Default to Gemini if unknown model
    return callGemini(request, "gemini-2.5-flash");
  }

  try {
    switch (config.provider) {
      case "gemini":
        if (geminiClient) {
          return await callGemini(request, config.modelId);
        }
        break;
      case "openai":
        if (openaiClient) {
          return await callOpenAI(openaiClient, request, config.modelId);
        }
        break;
      case "groq":
        if (groqClient) {
          return await callOpenAI(groqClient, request, config.modelId);
        }
        break;
    }

    // Fallback chain: try available providers
    if (geminiClient) {
      console.log(`Falling back to Gemini (${config.provider} not configured)`);
      return await callGemini(request, "gemini-2.5-flash");
    }
    if (openaiClient) {
      console.log(`Falling back to OpenAI (${config.provider} not configured)`);
      return await callOpenAI(openaiClient, request, "gpt-4o-mini");
    }
    if (groqClient) {
      console.log(`Falling back to Groq (${config.provider} not configured)`);
      return await callOpenAI(groqClient, request, "llama-3.1-8b-instant");
    }

    // No providers available - return demo response
    return getDemoResponse(request);
  } catch (error) {
    console.error(`AI chat error with ${config.provider}:`, error);
    // Try fallback providers
    if (config.provider !== "gemini" && geminiClient) {
      try {
        return await callGemini(request, "gemini-2.5-flash");
      } catch {}
    }
    if (config.provider !== "openai" && openaiClient) {
      try {
        return await callOpenAI(openaiClient, request, "gpt-4o-mini");
      } catch {}
    }
    return getDemoResponse(request);
  }
}

function getDemoResponse(request: ChatRequest): ChatResponse {
  const techniques = request.techniques || [];
  const content = `I'm SynapseAI running in demo mode. To enable full AI capabilities, configure one of:
- **GEMINI_API_KEY** for Google Gemini (free tier available)
- **OPENAI_API_KEY** for GPT-4o
- **GROQ_API_KEY** for Llama 3.3 (free tier available)

${techniques.length > 0 ? `I would have applied these techniques: ${techniques.join(", ")}` : ""}

**Platform Features:**
- **Chat**: Conversations with AI using advanced prompt techniques
- **Code**: Generate complete applications from descriptions
- **Preview**: Live preview of generated apps
- **Flow**: Visualize thinking and task pipelines
- **Agent**: Build autonomous agents with custom capabilities

Try asking me to "create a simple todo app" or "build a landing page"!`;

  return {
    content,
    tokenCount: content.length / 4,
    model: "demo",
  };
}

export async function generateCode(request: CodeGenerationRequest): Promise<CodeGenerationResponse> {
  const systemPrompt = `You are a code generation expert. Generate clean, well-structured, production-ready code.
  
When generating code:
1. Create all necessary files with appropriate names and extensions
2. Include proper imports and dependencies
3. Add helpful comments for complex logic
4. Follow best practices for the language/framework
5. Make the code immediately runnable

You MUST respond with valid JSON in exactly this format:
{
  "files": [
    { "name": "filename.ext", "language": "language", "content": "file content" }
  ],
  "explanation": "Brief explanation of what was generated"
}`;

  try {
    // Try Gemini first for code generation
    if (geminiClient) {
      const response = await geminiClient.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          temperature: 0.5,
          maxOutputTokens: 8192,
        },
        contents: request.prompt,
      });

      const rawJson = response.text;
      if (rawJson) {
        return JSON.parse(rawJson);
      }
    }

    // Try OpenAI
    if (openaiClient) {
      const response = await openaiClient.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: request.prompt },
        ],
        response_format: { type: "json_object" },
        temperature: 0.5,
        max_tokens: 8192,
      });

      const rawJson = response.choices[0]?.message?.content;
      if (rawJson) {
        return JSON.parse(rawJson);
      }
    }

    // Demo response
    return getDemoCodeResponse(request.prompt);
  } catch (error) {
    console.error("Code generation error:", error);
    return getDemoCodeResponse(request.prompt);
  }
}

function getDemoCodeResponse(prompt: string): CodeGenerationResponse {
  const isReact = prompt.toLowerCase().includes("react") || prompt.toLowerCase().includes("app");
  const isLanding = prompt.toLowerCase().includes("landing") || prompt.toLowerCase().includes("page");

  if (isLanding) {
    return {
      files: [{
        name: "LandingPage.tsx",
        language: "typescript",
        content: `export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Hero Section */}
      <header className="container mx-auto px-6 py-20 text-center">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
          Build Something
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
            {" "}Amazing
          </span>
        </h1>
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Create stunning applications with the power of AI. 
          No coding required - just describe what you want.
        </p>
        <div className="flex gap-4 justify-center">
          <button className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 text-white rounded-full font-semibold hover:opacity-90 transition">
            Get Started Free
          </button>
          <button className="px-8 py-3 border border-white/20 text-white rounded-full font-semibold hover:bg-white/10 transition">
            Watch Demo
          </button>
        </div>
      </header>

      {/* Features */}
      <section className="container mx-auto px-6 py-20">
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { title: "AI-Powered", desc: "Advanced AI generates code for you" },
            { title: "Real-Time", desc: "See changes instantly as you build" },
            { title: "Free Forever", desc: "Core features always free" }
          ].map((feature, i) => (
            <div key={i} className="p-6 rounded-2xl bg-white/5 backdrop-blur border border-white/10">
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}`,
      }],
      explanation: "Generated a modern landing page with hero section and features grid. Uses Tailwind CSS for styling with a neon gradient theme.",
    };
  }

  return {
    files: [{
      name: "App.tsx",
      language: "typescript",
      content: `import { useState } from 'react';

interface Todo {
  id: number;
  text: string;
  completed: boolean;
}

export default function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [input, setInput] = useState('');

  const addTodo = () => {
    if (input.trim()) {
      setTodos([...todos, { id: Date.now(), text: input, completed: false }]);
      setInput('');
    }
  };

  const toggleTodo = (id: number) => {
    setTodos(todos.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-500 to-purple-700 p-8">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-white text-center mb-8">
          SynapseAI Todo
        </h1>
        
        <div className="flex gap-2 mb-6">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTodo()}
            placeholder="Add a new task..."
            className="flex-1 px-4 py-2 rounded-lg bg-white/20 text-white placeholder-white/60 border border-white/20 focus:outline-none focus:border-white/40"
          />
          <button
            onClick={addTodo}
            className="px-6 py-2 bg-white text-purple-700 rounded-lg font-semibold hover:bg-white/90"
          >
            Add
          </button>
        </div>
        
        <ul className="space-y-2">
          {todos.map(todo => (
            <li
              key={todo.id}
              className="flex items-center gap-3 p-3 rounded-lg bg-white/10 backdrop-blur"
            >
              <input
                type="checkbox"
                checked={todo.completed}
                onChange={() => toggleTodo(todo.id)}
                className="w-5 h-5 rounded accent-purple-500"
              />
              <span className={\`flex-1 text-white \${todo.completed ? 'line-through opacity-60' : ''}\`}>
                {todo.text}
              </span>
              <button
                onClick={() => deleteTodo(todo.id)}
                className="text-white/60 hover:text-white"
              >
                x
              </button>
            </li>
          ))}
        </ul>
        
        {todos.length === 0 && (
          <p className="text-center text-white/60 py-8">
            No tasks yet. Add one above!
          </p>
        )}
      </div>
    </div>
  );
}`,
    }],
    explanation: "Generated a functional Todo app with add, toggle, and delete functionality. Uses React hooks for state management and Tailwind CSS for styling.",
  };
}

// Check which providers are configured
export function getConfiguredProviders(): string[] {
  const providers: string[] = [];
  if (geminiClient) providers.push("gemini");
  if (openaiClient) providers.push("openai");
  if (groqClient) providers.push("groq");
  return providers;
}

export function isConfigured(): boolean {
  return !!(geminiClient || openaiClient || groqClient);
}
