import { useState, useRef } from "react";
import { Upload, File, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  uploadedAt: Date;
  preview?: string;
}

interface FileUploadProps {
  onFilesSelected?: (files: UploadedFile[]) => void;
  maxSize?: number;
  acceptTypes?: string[];
}

export default function FileUpload({
  onFilesSelected,
  maxSize = 10 * 1024 * 1024,
  acceptTypes = ["image/*", ".txt", ".md", ".json", ".csv", ".pdf"],
}: FileUploadProps) {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = async (fileList: FileList) => {
    setError("");
    const newFiles: UploadedFile[] = [];

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];

      if (file.size > maxSize) {
        setError(`File ${file.name} is too large (max ${maxSize / 1024 / 1024}MB)`);
        continue;
      }

      const preview = file.type.startsWith("image/")
        ? await readFileAsDataURL(file)
        : undefined;

      newFiles.push({
        id: `file-${Date.now()}-${i}`,
        name: file.name,
        type: file.type,
        size: file.size,
        uploadedAt: new Date(),
        preview,
      });
    }

    const combined = [...uploadedFiles, ...newFiles];
    setUploadedFiles(combined);
    onFilesSelected?.(combined);
  };

  const readFileAsDataURL = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const removeFile = (id: string) => {
    const updated = uploadedFiles.filter(f => f.id !== id);
    setUploadedFiles(updated);
    onFilesSelected?.(updated);
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes}B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
  };

  return (
    <div className="space-y-4" data-testid="file-upload-container">
      {/* Drop zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`
          border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors
          ${isDragging 
            ? "border-primary bg-primary/5" 
            : "border-muted-foreground/30 hover:border-muted-foreground/50 hover:bg-muted/30"
          }
        `}
        data-testid="drop-zone"
      >
        <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
        <p className="font-medium text-sm mb-1">Drag files here or click to browse</p>
        <p className="text-xs text-muted-foreground">
          Images, documents, code files (max {maxSize / 1024 / 1024}MB)
        </p>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept={acceptTypes.join(",")}
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
          className="hidden"
          data-testid="file-input"
        />
      </div>

      {/* Error message */}
      {error && (
        <div className="p-3 rounded-md bg-red-500/10 text-red-600 dark:text-red-400 text-sm border border-red-200 dark:border-red-900">
          {error}
        </div>
      )}

      {/* Uploaded files list */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium">Uploaded Files ({uploadedFiles.length})</h4>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {uploadedFiles.map((file) => (
              <div
                key={file.id}
                className="flex items-start gap-3 p-2 rounded-md bg-muted/30 border border-border"
                data-testid={`uploaded-file-${file.id}`}
              >
                {file.preview ? (
                  <img
                    src={file.preview}
                    alt={file.name}
                    className="h-10 w-10 rounded object-cover flex-shrink-0"
                  />
                ) : (
                  <div className="h-10 w-10 rounded bg-muted flex items-center justify-center flex-shrink-0">
                    <File className="h-5 w-5 text-muted-foreground" />
                  </div>
                )}
                
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{file.name}</p>
                  <div className="flex gap-2 mt-1">
                    <Badge variant="secondary" className="text-xs">
                      {formatSize(file.size)}
                    </Badge>
                    <Badge variant="outline" className="text-xs text-green-600 dark:text-green-400">
                      <Check className="h-3 w-3 mr-1" />
                      Ready
                    </Badge>
                  </div>
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 flex-shrink-0"
                  onClick={() => removeFile(file.id)}
                  data-testid={`button-remove-file-${file.id}`}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
