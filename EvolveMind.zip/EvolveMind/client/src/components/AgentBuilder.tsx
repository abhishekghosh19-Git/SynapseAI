import { useState } from "react";
import { Bot, Plus, Trash2, Play, Settings, Zap, Brain, Globe, Wrench, ChevronRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

export interface AgentCapability {
  id: string;
  name: string;
  description: string;
  icon: "zap" | "brain" | "globe" | "wrench";
  enabled: boolean;
}

export interface AgentConfig {
  name: string;
  description: string;
  systemPrompt: string;
  capabilities: AgentCapability[];
  maxIterations: number;
  autoExecute: boolean;
}

interface AgentBuilderProps {
  config: AgentConfig;
  onConfigChange: (config: AgentConfig) => void;
  onDeploy?: () => void;
  onTest?: () => void;
  isDeploying?: boolean;
  isTesting?: boolean;
}

const iconMap = {
  zap: Zap,
  brain: Brain,
  globe: Globe,
  wrench: Wrench,
};

export default function AgentBuilder({
  config,
  onConfigChange,
  onDeploy,
  onTest,
  isDeploying = false,
  isTesting = false,
}: AgentBuilderProps) {
  const updateConfig = (updates: Partial<AgentConfig>) => {
    onConfigChange({ ...config, ...updates });
  };

  const toggleCapability = (id: string) => {
    const updated = config.capabilities.map((cap) =>
      cap.id === id ? { ...cap, enabled: !cap.enabled } : cap
    );
    updateConfig({ capabilities: updated });
  };

  const enabledCount = config.capabilities.filter((c) => c.enabled).length;

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <Bot className="h-4 w-4 text-primary" />
            Agent Builder
          </CardTitle>
          <div className="flex items-center gap-2">
            {onTest && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 gap-1.5"
                onClick={onTest}
                disabled={isTesting || isDeploying}
                data-testid="button-test-agent"
              >
                {isTesting ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Play className="h-3.5 w-3.5" />
                )}
                Test
              </Button>
            )}
            {onDeploy && (
              <Button
                size="sm"
                className="h-7 gap-1.5"
                onClick={onDeploy}
                disabled={isDeploying || isTesting}
                data-testid="button-deploy-agent"
              >
                {isDeploying ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Zap className="h-3.5 w-3.5" />
                )}
                Deploy
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 min-h-0 p-0">
        <ScrollArea className="h-full px-4 pb-4">
          <div className="space-y-6">
            {/* Basic Info */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="agent-name" className="text-xs">Agent Name</Label>
                <Input
                  id="agent-name"
                  value={config.name}
                  onChange={(e) => updateConfig({ name: e.target.value })}
                  placeholder="My Research Agent"
                  className="mt-1.5"
                  data-testid="input-agent-name"
                />
              </div>
              
              <div>
                <Label htmlFor="agent-description" className="text-xs">Description</Label>
                <Input
                  id="agent-description"
                  value={config.description}
                  onChange={(e) => updateConfig({ description: e.target.value })}
                  placeholder="An agent that helps with research tasks..."
                  className="mt-1.5"
                  data-testid="input-agent-description"
                />
              </div>
            </div>

            <Separator />

            {/* System Prompt */}
            <div>
              <Label htmlFor="system-prompt" className="text-xs">System Prompt</Label>
              <Textarea
                id="system-prompt"
                value={config.systemPrompt}
                onChange={(e) => updateConfig({ systemPrompt: e.target.value })}
                placeholder="You are a helpful research assistant that..."
                className="mt-1.5 min-h-[100px] text-sm"
                data-testid="textarea-system-prompt"
              />
            </div>

            <Separator />

            {/* Capabilities */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-xs">Capabilities</Label>
                <Badge variant="secondary" className="text-[10px]">
                  {enabledCount} enabled
                </Badge>
              </div>
              <div className="space-y-2">
                {config.capabilities.map((cap) => {
                  const Icon = iconMap[cap.icon];
                  return (
                    <div
                      key={cap.id}
                      className={`
                        flex items-center justify-between p-3 rounded-lg border transition-colors
                        ${cap.enabled ? "bg-primary/5 border-primary/20" : "bg-muted/30"}
                      `}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-1.5 rounded-md ${cap.enabled ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">{cap.name}</p>
                          <p className="text-xs text-muted-foreground">{cap.description}</p>
                        </div>
                      </div>
                      <Switch
                        checked={cap.enabled}
                        onCheckedChange={() => toggleCapability(cap.id)}
                        data-testid={`switch-capability-${cap.id}`}
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            <Separator />

            {/* Settings */}
            <div className="space-y-4">
              <Label className="text-xs flex items-center gap-2">
                <Settings className="h-3.5 w-3.5" />
                Advanced Settings
              </Label>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Max Iterations</p>
                  <p className="text-xs text-muted-foreground">Limit autonomous actions</p>
                </div>
                <Input
                  type="number"
                  value={config.maxIterations}
                  onChange={(e) => updateConfig({ maxIterations: parseInt(e.target.value) || 10 })}
                  className="w-20 text-center"
                  min={1}
                  max={100}
                  data-testid="input-max-iterations"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Auto-Execute</p>
                  <p className="text-xs text-muted-foreground">Run actions without confirmation</p>
                </div>
                <Switch
                  checked={config.autoExecute}
                  onCheckedChange={(val) => updateConfig({ autoExecute: val })}
                  data-testid="switch-auto-execute"
                />
              </div>
            </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
