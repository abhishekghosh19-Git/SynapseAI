import { Zap, Database, Brain, Gauge } from "lucide-react";
import PerformanceMetric, { type MetricData } from "../PerformanceMetric";

// todo: remove mock functionality
const mockMetrics: (MetricData & { icon: React.ReactNode })[] = [
  {
    label: "Token Efficiency",
    value: "87.3",
    unit: "%",
    trend: "up",
    trendValue: "+5.2%",
    description: "Compression ratio this session",
    icon: <Zap className="h-5 w-5" />,
  },
  {
    label: "Context Used",
    value: "24.5K",
    unit: "/ 128K",
    trend: "neutral",
    description: "Current context window usage",
    icon: <Database className="h-5 w-5" />,
  },
  {
    label: "Learning Rate",
    value: "0.618",
    trend: "up",
    trendValue: "+0.02",
    description: "Golden ratio optimized",
    icon: <Brain className="h-5 w-5" />,
  },
  {
    label: "Explore/Exploit",
    value: "32/68",
    unit: "%",
    trend: "down",
    trendValue: "-3%",
    description: "Exploitation increasing",
    icon: <Gauge className="h-5 w-5" />,
  },
];

export default function PerformanceMetricExample() {
  return (
    <div className="grid grid-cols-2 gap-3 w-full max-w-md">
      {mockMetrics.map((metric) => (
        <PerformanceMetric key={metric.label} metric={metric} icon={metric.icon} />
      ))}
    </div>
  );
}
