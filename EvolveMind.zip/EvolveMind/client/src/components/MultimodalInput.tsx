import { useState, useRef, useCallback } from "react";
import { Image, Mic, FileText, X, Upload, Camera, StopCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export interface Attachment {
  id: string;
  type: "image" | "audio" | "file";
  name: string;
  size: number;
  url?: string;
  file?: File;
  isProcessing?: boolean;
}

interface MultimodalInputProps {
  attachments: Attachment[];
  onAttachmentsChange: (attachments: Attachment[]) => void;
  isRecording?: boolean;
  onStartRecording?: () => void;
  onStopRecording?: () => void;
  maxAttachments?: number;
  acceptedTypes?: string;
}

const formatFileSize = (bytes: number) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

export default function MultimodalInput({
  attachments,
  onAttachmentsChange,
  isRecording = false,
  onStartRecording,
  onStopRecording,
  maxAttachments = 5,
  acceptedTypes = "image/*,audio/*,.pdf,.txt,.md,.json,.csv",
}: MultimodalInputProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>, type: "file" | "image") => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;

    const remaining = maxAttachments - attachments.length;
    const toAdd = files.slice(0, remaining);

    const newAttachments: Attachment[] = toAdd.map((file) => ({
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      type: file.type.startsWith("image/") ? "image" : file.type.startsWith("audio/") ? "audio" : "file",
      name: file.name,
      size: file.size,
      url: URL.createObjectURL(file),
      file,
      isProcessing: true,
    }));

    onAttachmentsChange([...attachments, ...newAttachments]);

    // Simulate processing
    setTimeout(() => {
      onAttachmentsChange([
        ...attachments,
        ...newAttachments.map((a) => ({ ...a, isProcessing: false })),
      ]);
    }, 1000);

    // Reset input
    event.target.value = "";
  }, [attachments, maxAttachments, onAttachmentsChange]);

  const removeAttachment = useCallback((id: string) => {
    const attachment = attachments.find((a) => a.id === id);
    if (attachment?.url) {
      URL.revokeObjectURL(attachment.url);
    }
    onAttachmentsChange(attachments.filter((a) => a.id !== id));
  }, [attachments, onAttachmentsChange]);

  const canAddMore = attachments.length < maxAttachments;

  return (
    <div className="space-y-2">
      {/* Attachment buttons */}
      <div className="flex items-center gap-1">
        <input
          ref={imageInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFileSelect(e, "image")}
          multiple
        />
        <input
          ref={fileInputRef}
          type="file"
          accept={acceptedTypes}
          className="hidden"
          onChange={(e) => handleFileSelect(e, "file")}
          multiple
        />

        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => imageInputRef.current?.click()}
          disabled={!canAddMore}
          data-testid="button-attach-image"
        >
          <Image className="h-4 w-4" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => fileInputRef.current?.click()}
          disabled={!canAddMore}
          data-testid="button-attach-file"
        >
          <FileText className="h-4 w-4" />
        </Button>

        {(onStartRecording || onStopRecording) && (
          <Button
            variant={isRecording ? "destructive" : "ghost"}
            size="icon"
            className="h-8 w-8"
            onClick={isRecording ? onStopRecording : onStartRecording}
            data-testid="button-voice-input"
          >
            {isRecording ? (
              <StopCircle className="h-4 w-4 animate-pulse" />
            ) : (
              <Mic className="h-4 w-4" />
            )}
          </Button>
        )}

        {attachments.length > 0 && (
          <Badge variant="secondary" className="text-[10px] ml-1">
            {attachments.length}/{maxAttachments}
          </Badge>
        )}
      </div>

      {/* Attachment previews */}
      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {attachments.map((attachment) => (
            <div
              key={attachment.id}
              className="relative group flex items-center gap-2 px-2 py-1.5 rounded-lg border bg-muted/30 max-w-[200px]"
            >
              {attachment.isProcessing && (
                <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
              )}
              
              {!attachment.isProcessing && attachment.type === "image" && attachment.url && (
                <img
                  src={attachment.url}
                  alt={attachment.name}
                  className="h-8 w-8 rounded object-cover"
                />
              )}
              
              {!attachment.isProcessing && attachment.type !== "image" && (
                <div className="h-8 w-8 rounded bg-muted flex items-center justify-center">
                  {attachment.type === "audio" ? (
                    <Mic className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
              )}
              
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">{attachment.name}</p>
                <p className="text-[10px] text-muted-foreground">
                  {formatFileSize(attachment.size)}
                </p>
              </div>
              
              <Button
                variant="ghost"
                size="icon"
                className="h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => removeAttachment(attachment.id)}
                data-testid={`button-remove-attachment-${attachment.id}`}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
