import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronUp } from "lucide-react";

interface DiffLine {
  type: "add" | "remove" | "context";
  content: string;
  lineNumber?: number;
}

interface DiffViewerProps {
  oldContent: string;
  newContent: string;
  fileName: string;
  onAccept?: () => void;
  onReject?: () => void;
}

function computeDiff(old: string, newer: string): DiffLine[] {
  const oldLines = old.split("\n");
  const newLines = newer.split("\n");
  const diff: DiffLine[] = [];
  
  let i = 0, j = 0;
  while (i < oldLines.length || j < newLines.length) {
    if (i >= oldLines.length) {
      diff.push({ type: "add", content: newLines[j] });
      j++;
    } else if (j >= newLines.length) {
      diff.push({ type: "remove", content: oldLines[i] });
      i++;
    } else if (oldLines[i] === newLines[j]) {
      diff.push({ type: "context", content: oldLines[i] });
      i++;
      j++;
    } else {
      diff.push({ type: "remove", content: oldLines[i] });
      diff.push({ type: "add", content: newLines[j] });
      i++;
      j++;
    }
  }
  return diff;
}

export default function DiffViewer({
  oldContent,
  newContent,
  fileName,
  onAccept,
  onReject,
}: DiffViewerProps) {
  const [expanded, setExpanded] = useState(true);
  const diff = computeDiff(oldContent, newContent);
  
  const addCount = diff.filter(d => d.type === "add").length;
  const removeCount = diff.filter(d => d.type === "remove").length;

  return (
    <div className="border rounded-lg bg-card overflow-hidden">
      {/* Header */}
      <div className="bg-muted/50 border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setExpanded(!expanded)}
            className="hover:bg-muted rounded p-1"
            data-testid="button-toggle-diff"
          >
            {expanded ? (
              <ChevronUp className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </button>
          <span className="font-mono text-sm font-medium">{fileName}</span>
          <Badge variant="secondary" className="text-xs">
            <span className="text-green-600 dark:text-green-400 mr-1">+{addCount}</span>
            <span className="text-red-600 dark:text-red-400">-{removeCount}</span>
          </Badge>
        </div>
        
        {onAccept || onReject ? (
          <div className="flex gap-2">
            {onReject && (
              <Button
                size="sm"
                variant="outline"
                onClick={onReject}
                data-testid="button-reject-diff"
              >
                Reject
              </Button>
            )}
            {onAccept && (
              <Button
                size="sm"
                onClick={onAccept}
                data-testid="button-accept-diff"
              >
                Accept
              </Button>
            )}
          </div>
        ) : null}
      </div>

      {/* Diff content */}
      {expanded && (
        <div className="font-mono text-xs overflow-x-auto max-h-96 bg-background">
          {diff.length === 0 ? (
            <div className="p-4 text-muted-foreground">No changes</div>
          ) : (
            <table className="w-full border-collapse">
              <tbody>
                {diff.map((line, idx) => (
                  <tr
                    key={idx}
                    className={`
                      border-b border-border last:border-b-0
                      ${line.type === "add" ? "bg-green-500/10" : ""}
                      ${line.type === "remove" ? "bg-red-500/10" : ""}
                    `}
                  >
                    <td
                      className={`
                        w-6 px-2 py-1 select-none text-right text-muted-foreground
                        ${line.type === "add" ? "text-green-600 dark:text-green-400 font-bold" : ""}
                        ${line.type === "remove" ? "text-red-600 dark:text-red-400 font-bold" : ""}
                      `}
                      data-testid={`diff-${line.type}`}
                    >
                      {line.type === "add" ? "+" : line.type === "remove" ? "-" : " "}
                    </td>
                    <td className="flex-1 px-3 py-1 whitespace-pre-wrap break-words max-w-2xl">
                      {line.content || " "}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}
