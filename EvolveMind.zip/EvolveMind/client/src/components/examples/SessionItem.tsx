import { useState } from "react";
import SessionItem, { type Session } from "../SessionItem";

// todo: remove mock functionality
const mockSessions: Session[] = [
  {
    id: "1",
    title: "Chain of Thought Analysis",
    preview: "Exploring step-by-step reasoning techniques...",
    messageCount: 12,
    updatedAt: new Date(),
    model: "Gemini 2.5",
  },
  {
    id: "2",
    title: "ReAct Agent Development",
    preview: "Building an autonomous research agent...",
    messageCount: 24,
    updatedAt: new Date(Date.now() - 86400000),
    model: "Llama 3.3",
  },
  {
    id: "3",
    title: "Context Compression Testing",
    preview: "Optimizing token usage with semantic chunking...",
    messageCount: 8,
    updatedAt: new Date(Date.now() - 172800000),
    model: "GPT-4o",
  },
];

export default function SessionItemExample() {
  const [activeId, setActiveId] = useState("1");

  return (
    <div className="w-64 space-y-1 p-2 bg-sidebar rounded-lg">
      {mockSessions.map((session) => (
        <SessionItem
          key={session.id}
          session={session}
          isActive={session.id === activeId}
          onClick={() => setActiveId(session.id)}
          onRename={() => console.log("Rename:", session.id)}
          onArchive={() => console.log("Archive:", session.id)}
          onDelete={() => console.log("Delete:", session.id)}
        />
      ))}
    </div>
  );
}
