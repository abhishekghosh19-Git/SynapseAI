import { useState } from "react";
import { X, ChevronRight, ChevronLeft, Sparkles, Zap, Brain, Code, Rocket, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  icon: typeof Sparkles;
  tip?: string;
}

interface OnboardingGuideProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

const steps: OnboardingStep[] = [
  {
    id: "welcome",
    title: "Welcome to SynapseAI",
    description: "Your self-evolving AI agent platform. Create apps, automate tasks, and build intelligent agents - all for free.",
    icon: Sparkles,
    tip: "SynapseAI uses free-tier APIs from Google, Groq, and OpenRouter to keep everything completely free.",
  },
  {
    id: "models",
    title: "Multi-Model AI",
    description: "Choose from multiple AI models including Gemini 2.5 Flash, Llama 3.3, and GPT-4o. Each has unique strengths for different tasks.",
    icon: Brain,
    tip: "Models marked 'Free' use free API tiers. Gemini 2.5 Flash offers 1M token context with 1,500 requests/day.",
  },
  {
    id: "techniques",
    title: "Prompt Engineering Library",
    description: "Access 25+ advanced techniques like Chain of Thought, ReAct, and Tree of Thoughts. Mix and match for optimal results.",
    icon: Zap,
    tip: "Click the sparkle icon in the input area to open the technique library. Each technique improves accuracy for specific task types.",
  },
  {
    id: "code",
    title: "Live Code Generation",
    description: "Generate complete applications, websites, and agents from natural language. See live previews instantly.",
    icon: Code,
    tip: "Ask to 'create a todo app' or 'build a landing page' and watch the code generate in real-time.",
  },
  {
    id: "deploy",
    title: "One-Click Deploy",
    description: "Deploy your creations instantly. Share your apps with the world with a single click.",
    icon: Rocket,
    tip: "All deployments are free and include automatic HTTPS, custom domains, and global CDN.",
  },
];

export default function OnboardingGuide({
  isOpen,
  onClose,
  onComplete,
}: OnboardingGuideProps) {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const step = steps[currentStep];
  const progress = ((currentStep + 1) / steps.length) * 100;
  const isLast = currentStep === steps.length - 1;
  const Icon = step.icon;

  const handleNext = () => {
    if (isLast) {
      onComplete();
      onClose();
    } else {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    setCurrentStep((prev) => Math.max(0, prev - 1));
  };

  const handleSkip = () => {
    onComplete();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
      <Card className="w-full max-w-lg mx-4 relative overflow-hidden">
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-violet-500/5" />
        
        <CardContent className="relative p-6">
          {/* Close button */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 h-8 w-8"
            onClick={handleSkip}
            data-testid="button-close-onboarding"
          >
            <X className="h-4 w-4" />
          </Button>

          {/* Progress */}
          <div className="mb-6">
            <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
              <span>Step {currentStep + 1} of {steps.length}</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-1" />
          </div>

          {/* Step indicators */}
          <div className="flex justify-center gap-2 mb-6">
            {steps.map((s, i) => (
              <button
                key={s.id}
                className={`
                  w-2 h-2 rounded-full transition-all
                  ${i === currentStep ? "bg-primary w-4" : i < currentStep ? "bg-primary/60" : "bg-muted"}
                `}
                onClick={() => setCurrentStep(i)}
              />
            ))}
          </div>

          {/* Content */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-violet-500/20 mb-4">
              <Icon className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-xl font-semibold mb-2">{step.title}</h2>
            <p className="text-muted-foreground">{step.description}</p>
          </div>

          {/* Tip */}
          {step.tip && (
            <div className="bg-muted/50 rounded-lg p-4 mb-6">
              <div className="flex items-start gap-2">
                <Badge variant="outline" className="text-[10px] mt-0.5">TIP</Badge>
                <p className="text-sm text-muted-foreground">{step.tip}</p>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={handlePrev}
              disabled={currentStep === 0}
              className="gap-1"
              data-testid="button-prev-step"
            >
              <ChevronLeft className="h-4 w-4" />
              Back
            </Button>
            
            <Button
              variant="ghost"
              onClick={handleSkip}
              className="text-muted-foreground"
              data-testid="button-skip-onboarding"
            >
              Skip Tour
            </Button>
            
            <Button
              onClick={handleNext}
              className="gap-1"
              data-testid="button-next-step"
            >
              {isLast ? (
                <>
                  Get Started
                  <Check className="h-4 w-4" />
                </>
              ) : (
                <>
                  Next
                  <ChevronRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
