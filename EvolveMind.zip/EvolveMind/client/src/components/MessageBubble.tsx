import { Copy, Check, RotateCcw, ThumbsUp, ThumbsDown } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  model?: string;
  techniques?: string[];
  tokenCount?: number;
  compressionRatio?: number;
}

interface MessageBubbleProps {
  message: Message;
  onCopy?: () => void;
  onRegenerate?: () => void;
  onFeedback?: (type: "up" | "down") => void;
}

export default function MessageBubble({
  message,
  onCopy,
  onRegenerate,
  onFeedback,
}: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<"up" | "down" | null>(null);
  const isUser = message.role === "user";

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    onCopy?.();
  };

  const handleFeedback = (type: "up" | "down") => {
    setFeedback(type);
    onFeedback?.(type);
  };

  return (
    <div
      className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}
      data-testid={`message-${message.id}`}
    >
      <Avatar className={`h-8 w-8 flex-shrink-0 ${isUser ? "bg-primary" : "bg-gradient-to-br from-violet-500 to-indigo-600"}`}>
        <AvatarFallback className="text-white text-xs font-medium">
          {isUser ? "U" : "AI"}
        </AvatarFallback>
      </Avatar>

      <div className={`flex flex-col gap-1 ${isUser ? "items-end" : "items-start"} max-w-[75%]`}>
        <div
          className={`
            rounded-2xl px-4 py-3 text-sm leading-relaxed
            ${isUser
              ? "bg-primary text-primary-foreground rounded-br-md"
              : "bg-card border border-card-border rounded-bl-md"
            }
          `}
        >
          <div className="whitespace-pre-wrap break-words">{message.content}</div>
        </div>

        <div className={`flex items-center gap-1 px-1 ${isUser ? "flex-row-reverse" : ""}`}>
          {!isUser && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={handleCopy}
                data-testid="button-copy-message"
              >
                {copied ? (
                  <Check className="h-3.5 w-3.5 text-green-500" />
                ) : (
                  <Copy className="h-3.5 w-3.5 text-muted-foreground" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={onRegenerate}
                data-testid="button-regenerate"
              >
                <RotateCcw className="h-3.5 w-3.5 text-muted-foreground" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={`h-7 w-7 ${feedback === "up" ? "text-green-500" : ""}`}
                onClick={() => handleFeedback("up")}
                data-testid="button-feedback-up"
              >
                <ThumbsUp className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={`h-7 w-7 ${feedback === "down" ? "text-destructive" : ""}`}
                onClick={() => handleFeedback("down")}
                data-testid="button-feedback-down"
              >
                <ThumbsDown className="h-3.5 w-3.5" />
              </Button>
            </>
          )}
          <span className="text-xs text-muted-foreground px-1">
            {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
          {message.tokenCount && (
            <span className="text-xs text-muted-foreground">
              {message.tokenCount} tokens
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
