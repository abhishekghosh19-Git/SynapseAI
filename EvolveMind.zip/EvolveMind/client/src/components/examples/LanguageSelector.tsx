import { useState } from "react";
import LanguageSelector, { type Language } from "../LanguageSelector";

// todo: remove mock functionality
const mockLanguages: Language[] = [
  { code: "en", name: "English", nativeName: "English", flag: "\u{1F1FA}\u{1F1F8}" },
  { code: "es", name: "Spanish", nativeName: "Espanol", flag: "\u{1F1EA}\u{1F1F8}" },
  { code: "fr", name: "French", nativeName: "Francais", flag: "\u{1F1EB}\u{1F1F7}" },
  { code: "de", name: "German", nativeName: "Deutsch", flag: "\u{1F1E9}\u{1F1EA}" },
  { code: "zh", name: "Chinese", nativeName: "\u4E2D\u6587", flag: "\u{1F1E8}\u{1F1F3}" },
  { code: "ja", name: "Japanese", nativeName: "\u65E5\u672C\u8A9E", flag: "\u{1F1EF}\u{1F1F5}" },
  { code: "ar", name: "Arabic", nativeName: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629", flag: "\u{1F1F8}\u{1F1E6}" },
  { code: "hi", name: "Hindi", nativeName: "\u0939\u093F\u0928\u094D\u0926\u0940", flag: "\u{1F1EE}\u{1F1F3}" },
];

export default function LanguageSelectorExample() {
  const [selectedLanguage, setSelectedLanguage] = useState(mockLanguages[0]);

  return (
    <LanguageSelector
      languages={mockLanguages}
      selectedLanguage={selectedLanguage}
      onLanguageChange={setSelectedLanguage}
    />
  );
}
