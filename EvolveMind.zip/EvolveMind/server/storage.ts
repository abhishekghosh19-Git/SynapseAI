import { 
  type User, type InsertUser, 
  type Session, type InsertSession,
  type Message, type InsertMessage,
  type GeneratedFile, type InsertGeneratedFile,
  type Agent, type InsertAgent
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Sessions
  getSessions(): Promise<Session[]>;
  getSession(id: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: string, updates: Partial<InsertSession>): Promise<Session | undefined>;
  deleteSession(id: string): Promise<boolean>;
  
  // Messages
  getMessagesBySession(sessionId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Generated Files
  getFilesBySession(sessionId: string): Promise<GeneratedFile[]>;
  createFile(file: InsertGeneratedFile): Promise<GeneratedFile>;
  updateFile(id: string, content: string): Promise<GeneratedFile | undefined>;
  getFileVersions(sessionId: string, name: string): Promise<GeneratedFile[]>;
  
  // Agents
  getAgents(): Promise<Agent[]>;
  getAgent(id: string): Promise<Agent | undefined>;
  createAgent(agent: InsertAgent): Promise<Agent>;
  updateAgent(id: string, updates: Partial<InsertAgent>): Promise<Agent | undefined>;
  deleteAgent(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private sessions: Map<string, Session>;
  private messages: Map<string, Message>;
  private files: Map<string, GeneratedFile>;
  private agents: Map<string, Agent>;

  constructor() {
    this.users = new Map();
    this.sessions = new Map();
    this.messages = new Map();
    this.files = new Map();
    this.agents = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Session methods
  async getSessions(): Promise<Session[]> {
    return Array.from(this.sessions.values())
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  async getSession(id: string): Promise<Session | undefined> {
    return this.sessions.get(id);
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = randomUUID();
    const now = new Date();
    const session: Session = { 
      id,
      title: insertSession.title,
      preview: insertSession.preview ?? null,
      model: insertSession.model,
      createdAt: now, 
      updatedAt: now 
    };
    this.sessions.set(id, session);
    return session;
  }

  async updateSession(id: string, updates: Partial<InsertSession>): Promise<Session | undefined> {
    const session = this.sessions.get(id);
    if (!session) return undefined;
    const updated: Session = { 
      ...session, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.sessions.set(id, updated);
    return updated;
  }

  async deleteSession(id: string): Promise<boolean> {
    return this.sessions.delete(id);
  }

  // Message methods
  async getMessagesBySession(sessionId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => m.sessionId === sessionId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = { 
      id,
      sessionId: insertMessage.sessionId,
      role: insertMessage.role,
      content: insertMessage.content,
      model: insertMessage.model ?? null,
      tokenCount: insertMessage.tokenCount ?? null,
      techniques: insertMessage.techniques ?? null,
      createdAt: new Date() 
    };
    this.messages.set(id, message);
    return message;
  }

  // File methods
  async getFilesBySession(sessionId: string): Promise<GeneratedFile[]> {
    return Array.from(this.files.values())
      .filter(f => f.sessionId === sessionId)
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  async createFile(insertFile: InsertGeneratedFile): Promise<GeneratedFile> {
    const id = randomUUID();
    const now = new Date();
    const file: GeneratedFile = { 
      ...insertFile, 
      id, 
      version: 1,
      createdAt: now, 
      updatedAt: now 
    };
    this.files.set(id, file);
    return file;
  }

  async updateFile(id: string, content: string): Promise<GeneratedFile | undefined> {
    const file = this.files.get(id);
    if (!file) return undefined;
    
    // Store previous version
    const versionId = randomUUID();
    const previousVersion: GeneratedFile = { 
      ...file, 
      id: versionId,
    };
    this.files.set(versionId, previousVersion);
    
    // Update current file
    const updated: GeneratedFile = { 
      ...file, 
      content, 
      version: file.version + 1,
      updatedAt: new Date() 
    };
    this.files.set(id, updated);
    return updated;
  }

  async getFileVersions(sessionId: string, name: string): Promise<GeneratedFile[]> {
    return Array.from(this.files.values())
      .filter(f => f.sessionId === sessionId && f.name === name)
      .sort((a, b) => b.version - a.version);
  }

  // Agent methods
  async getAgents(): Promise<Agent[]> {
    return Array.from(this.agents.values())
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  async getAgent(id: string): Promise<Agent | undefined> {
    return this.agents.get(id);
  }

  async createAgent(insertAgent: InsertAgent): Promise<Agent> {
    const id = randomUUID();
    const now = new Date();
    const agent: Agent = { 
      id,
      name: insertAgent.name,
      description: insertAgent.description ?? null,
      systemPrompt: insertAgent.systemPrompt,
      capabilities: insertAgent.capabilities,
      maxIterations: insertAgent.maxIterations ?? 10,
      autoExecute: insertAgent.autoExecute ?? false,
      createdAt: now, 
      updatedAt: now 
    };
    this.agents.set(id, agent);
    return agent;
  }

  async updateAgent(id: string, updates: Partial<InsertAgent>): Promise<Agent | undefined> {
    const agent = this.agents.get(id);
    if (!agent) return undefined;
    const updated: Agent = { 
      ...agent, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.agents.set(id, updated);
    return updated;
  }

  async deleteAgent(id: string): Promise<boolean> {
    return this.agents.delete(id);
  }
}

export const storage = new MemStorage();
