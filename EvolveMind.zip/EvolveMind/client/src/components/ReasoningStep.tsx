import { useState } from "react";
import { ChevronRight, ChevronDown, Brain, Wrench, Eye, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export type StepType = "thought" | "action" | "observation" | "result";
export type StepStatus = "pending" | "running" | "complete" | "error";

export interface ReasoningStepData {
  id: string;
  type: StepType;
  content: string;
  status: StepStatus;
  children?: ReasoningStepData[];
  tool?: string;
  duration?: number;
}

interface ReasoningStepProps {
  step: ReasoningStepData;
  depth?: number;
}

const typeIcons: Record<StepType, typeof Brain> = {
  thought: Brain,
  action: Wrench,
  observation: Eye,
  result: CheckCircle,
};

const typeColors: Record<StepType, string> = {
  thought: "text-blue-500",
  action: "text-amber-500",
  observation: "text-green-500",
  result: "text-purple-500",
};

const statusIcons: Record<StepStatus, typeof Loader2 | null> = {
  pending: null,
  running: Loader2,
  complete: CheckCircle,
  error: AlertCircle,
};

export default function ReasoningStep({ step, depth = 0 }: ReasoningStepProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const hasChildren = step.children && step.children.length > 0;
  const Icon = typeIcons[step.type];
  const StatusIcon = statusIcons[step.status];

  return (
    <div className="relative" data-testid={`reasoning-step-${step.id}`}>
      {depth > 0 && (
        <div
          className="absolute left-0 top-0 bottom-0 w-px bg-border"
          style={{ marginLeft: `${(depth - 1) * 24 + 11}px` }}
        />
      )}

      <div
        className={`
          flex items-start gap-2 py-2 px-2 rounded-md cursor-pointer
          hover:bg-muted/50 transition-colors
        `}
        style={{ paddingLeft: `${depth * 24 + 8}px` }}
        onClick={() => hasChildren && setIsExpanded(!isExpanded)}
      >
        {hasChildren ? (
          <button className="p-0.5 mt-0.5 hover:bg-muted rounded">
            {isExpanded ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
        ) : (
          <div className="w-5" />
        )}

        <Icon className={`h-4 w-4 mt-0.5 flex-shrink-0 ${typeColors[step.type]}`} />

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="text-[10px] px-1.5 py-0 capitalize">
              {step.type}
            </Badge>
            {step.tool && (
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 font-mono">
                {step.tool}
              </Badge>
            )}
            {step.duration && (
              <span className="text-[10px] text-muted-foreground">
                {step.duration}ms
              </span>
            )}
          </div>
          <p className="text-sm mt-1 text-foreground/90 break-words">{step.content}</p>
        </div>

        {StatusIcon && (
          <StatusIcon
            className={`h-4 w-4 flex-shrink-0 ${
              step.status === "running"
                ? "animate-spin text-primary"
                : step.status === "complete"
                ? "text-green-500"
                : "text-destructive"
            }`}
          />
        )}
      </div>

      {hasChildren && isExpanded && (
        <div className="relative">
          {step.children!.map((child) => (
            <ReasoningStep key={child.id} step={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}
