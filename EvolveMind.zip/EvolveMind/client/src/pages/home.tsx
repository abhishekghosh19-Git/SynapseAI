import { useState, useCallback, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  PanelRightOpen, PanelRightClose, Code, Eye, Bot, GitBranch, 
  Sparkles, MessageSquare, Maximize2, Minimize2, AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { Alert, AlertDescription } from "@/components/ui/alert";
import AppSidebar from "@/components/AppSidebar";
import ChatArea from "@/components/ChatArea";
import InspectorPanel from "@/components/InspectorPanel";
import PromptTechniqueLibrary from "@/components/PromptTechniqueLibrary";
import ThemeToggle from "@/components/ThemeToggle";
import CodeEditorWithDiff, { type CodeFile } from "@/components/CodeEditorWithDiff";
import LivePreview from "@/components/LivePreview";
import SystemsThinkingFlow, { type FlowNode } from "@/components/SystemsThinkingFlow";
import AgentBuilder, { type AgentConfig } from "@/components/AgentBuilder";
import OnboardingGuide from "@/components/OnboardingGuide";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { AIModel } from "@/components/ModelSelector";
import type { Language } from "@/components/LanguageSelector";
import type { Session } from "@/components/SessionItem";
import type { Message } from "@/components/MessageBubble";
import type { PromptTechnique } from "@/components/PromptTechniqueBadge";
import type { ReasoningStepData } from "@/components/ReasoningStep";
import type { MetricData } from "@/components/PerformanceMetric";

const availableModels: AIModel[] = [
  { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash", provider: "Google", description: "1M tokens, 1500 req/day free", isFree: true, icon: "zap" },
  { id: "llama-3.3-70b", name: "Llama 3.3 70B", provider: "Groq", description: "Ultra-fast inference, free tier", isFree: true, icon: "brain" },
  { id: "gpt-4o", name: "GPT-4o", provider: "OpenAI", description: "Most capable, paid", isFree: false, icon: "sparkles" },
  { id: "deepseek-v3", name: "DeepSeek V3", provider: "OpenRouter", description: "128K context, cost-efficient", isFree: true, icon: "globe" },
];

const availableLanguages: Language[] = [
  { code: "en", name: "English", nativeName: "English", flag: "\u{1F1FA}\u{1F1F8}" },
  { code: "es", name: "Spanish", nativeName: "Espanol", flag: "\u{1F1EA}\u{1F1F8}" },
  { code: "fr", name: "French", nativeName: "Francais", flag: "\u{1F1EB}\u{1F1F7}" },
  { code: "de", name: "German", nativeName: "Deutsch", flag: "\u{1F1E9}\u{1F1EA}" },
  { code: "zh", name: "Chinese", nativeName: "\u4E2D\u6587", flag: "\u{1F1E8}\u{1F1F3}" },
  { code: "ja", name: "Japanese", nativeName: "\u65E5\u672C\u8A9E", flag: "\u{1F1EF}\u{1F1F5}" },
];

const allTechniques: PromptTechnique[] = [
  { id: "cot", name: "Chain of Thought", shortName: "CoT", description: "Step-by-step reasoning before answering", category: "reasoning", useCases: ["Math", "Logic", "Analysis"] },
  { id: "react", name: "ReAct", shortName: "ReAct", description: "Reasoning + Acting with tool use", category: "reasoning", useCases: ["Research", "Tools", "Data"] },
  { id: "tot", name: "Tree of Thoughts", shortName: "ToT", description: "Explore multiple reasoning branches", category: "reasoning", useCases: ["Creative", "Strategy", "Decisions"] },
  { id: "self-consistency", name: "Self-Consistency", shortName: "SC", description: "Generate multiple answers, select most consistent", category: "reasoning", useCases: ["Math", "Critical", "Validation"] },
  { id: "rag", name: "Retrieval Augmented", shortName: "RAG", description: "Retrieve external knowledge", category: "retrieval", useCases: ["Documentation", "Research", "Facts"] },
  { id: "reflexion", name: "Reflexion", shortName: "Reflexion", description: "Self-evaluate and improve outputs", category: "refinement", useCases: ["Code review", "Writing", "QA"] },
  { id: "costar", name: "COSTAR Framework", shortName: "COSTAR", description: "Context, Objective, Style, Tone, Audience, Response", category: "framework", useCases: ["Business", "Content", "Tasks"] },
  { id: "persona", name: "Persona Pattern", shortName: "Persona", description: "Assign specific role or expertise", category: "framework", useCases: ["Expert advice", "Role-play", "Knowledge"] },
  { id: "mdp", name: "MDP Agent", shortName: "MDP", description: "Markov Decision Process for optimal actions", category: "advanced", useCases: ["Planning", "Decisions", "Games"] },
  { id: "meta-learning", name: "Meta-Learning", shortName: "MetaL", description: "Learn to optimize learning process", category: "advanced", useCases: ["Self-improvement", "Adaptation", "Patterns"] },
];

const defaultMetrics: MetricData[] = [
  { label: "Token Efficiency", value: "87.3", unit: "%", trend: "up", trendValue: "+5.2%", description: "Compression ratio this session" },
  { label: "Context Used", value: "24.5K", unit: "/ 128K", trend: "neutral", description: "Current context window usage" },
  { label: "Learning Rate", value: "0.618", trend: "up", trendValue: "+0.02", description: "Golden ratio optimized" },
  { label: "Explore/Exploit", value: "32/68", unit: "%", trend: "down", trendValue: "-3%", description: "Exploitation increasing" },
];

const defaultMemorySlots = [
  { id: "1", label: "Chain of Thought patterns", tokens: 1250, similarity: 0.92 },
  { id: "2", label: "Previous context summary", tokens: 890, similarity: 0.85 },
  { id: "3", label: "Tool usage history", tokens: 450, similarity: 0.78 },
];

const defaultFlowNodes: FlowNode[] = [
  { id: "1", label: "Analyze Request", description: "Parse user intent and requirements", type: "input", status: "pending", duration: 0 },
  { id: "2", label: "Select Techniques", description: "Choose optimal prompt engineering techniques", type: "decision", status: "pending", dependencies: ["1"] },
  { id: "3", label: "Generate Response", description: "Create AI-powered response", type: "process", status: "pending", dependencies: ["2"] },
  { id: "4", label: "Self-Review", description: "Validate quality and completeness", type: "agent", status: "pending", dependencies: ["3"] },
  { id: "5", label: "Deliver", description: "Present final output", type: "output", status: "pending", dependencies: ["4"] },
];

const defaultAgentConfig: AgentConfig = {
  name: "Research Assistant",
  description: "An autonomous agent that helps with research tasks",
  systemPrompt: "You are a helpful research assistant that gathers information, analyzes data, and provides comprehensive summaries.",
  capabilities: [
    { id: "web", name: "Web Search", description: "Search the internet for information", icon: "globe", enabled: true },
    { id: "code", name: "Code Generation", description: "Write and execute code", icon: "zap", enabled: true },
    { id: "analysis", name: "Data Analysis", description: "Analyze data and create visualizations", icon: "brain", enabled: false },
    { id: "tools", name: "Tool Use", description: "Use external tools and APIs", icon: "wrench", enabled: false },
  ],
  maxIterations: 10,
  autoExecute: false,
};

type WorkspaceTab = "chat" | "code" | "preview" | "flow" | "agent";

export default function Home() {
  // UI State
  const [selectedModel, setSelectedModel] = useState(availableModels[0]);
  const [selectedLanguage, setSelectedLanguage] = useState(availableLanguages[0]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeTechniques, setActiveTechniques] = useState<PromptTechnique[]>([allTechniques[0]]);
  const [isTechniqueLibraryOpen, setIsTechniqueLibraryOpen] = useState(false);
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);
  const [reasoningTree, setReasoningTree] = useState<ReasoningStepData | null>(null);
  const [settings, setSettings] = useState({
    epsilon: 0.32,
    compressionThreshold: 75,
    selfReflectionDepth: 2,
    metaLearningEnabled: true,
    goldenRatioOptimization: true,
  });
  
  // Workspace state
  const [workspaceTab, setWorkspaceTab] = useState<WorkspaceTab>("chat");
  const [codeFiles, setCodeFiles] = useState<CodeFile[]>([]);
  const [activeFileId, setActiveFileId] = useState<string>("");
  const [uploadedFiles, setUploadedFiles] = useState<any[]>([]);
  const [flowNodes, setFlowNodes] = useState(defaultFlowNodes);
  const [isFlowRunning, setIsFlowRunning] = useState(false);
  const [agentConfig, setAgentConfig] = useState(defaultAgentConfig);
  const [showOnboarding, setShowOnboarding] = useState(() => {
    return !localStorage.getItem("synapse-onboarding-complete");
  });
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [previewHtml, setPreviewHtml] = useState<string>("");

  // API Status
  const { data: status } = useQuery<{ configured: boolean }>({
    queryKey: ['/api/status'],
  });

  // Sessions API
  const { data: sessions = [], isLoading: sessionsLoading } = useQuery<Session[]>({
    queryKey: ['/api/sessions'],
  });

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (data: { title: string; model: string; preview?: string }) => {
      return apiRequest('/api/sessions', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: (newSession: Session) => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      setActiveSessionId(newSession.id);
      setMessages([]);
    },
  });

  // Delete session mutation
  const deleteSessionMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/sessions/${id}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
    },
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { content: string; techniques: string[]; model: string }) => {
      if (!activeSessionId) throw new Error("No active session");
      return apiRequest(`/api/sessions/${activeSessionId}/messages`, {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: (response) => {
      const { userMessage, assistantMessage } = response;
      
      // Update messages with the response
      setMessages((prev) => [
        ...prev.filter(m => m.id !== `temp-${Date.now()}`),
        {
          id: userMessage.id,
          role: "user",
          content: userMessage.content,
          timestamp: new Date(userMessage.createdAt),
        },
        {
          id: assistantMessage.id,
          role: "assistant",
          content: assistantMessage.content,
          timestamp: new Date(assistantMessage.createdAt),
          model: assistantMessage.model,
          tokenCount: assistantMessage.tokenCount,
        },
      ]);

      // Complete reasoning tree
      setReasoningTree((prev) => prev ? {
        ...prev,
        status: "complete",
        children: prev.children?.map(c => ({ ...c, status: "complete" as const })),
      } : null);

      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
    },
  });

  // Generate code mutation
  const generateCodeMutation = useMutation({
    mutationFn: async (prompt: string) => {
      return apiRequest('/api/generate-code', {
        method: 'POST',
        body: JSON.stringify({ prompt, sessionId: activeSessionId }),
      });
    },
    onSuccess: (response) => {
      const files: CodeFile[] = response.files.map((f: { name: string; language: string; content: string }, i: number) => ({
        id: `file-${i}-${Date.now()}`,
        name: f.name,
        language: f.language,
        content: f.content,
        isModified: false,
      }));
      setCodeFiles(files);
      if (files.length > 0) {
        setActiveFileId(files[0].id);
        // Generate preview HTML
        const mainFile = files.find(f => f.name.endsWith('.tsx') || f.name.endsWith('.jsx') || f.name.endsWith('.html'));
        if (mainFile) {
          generatePreview(files);
        }
      }
      setWorkspaceTab("code");
      
      // Update flow nodes
      setFlowNodes(prev => prev.map((n, i) => ({
        ...n,
        status: "completed" as const,
        duration: Math.floor(Math.random() * 500) + 100,
      })));
      setIsFlowRunning(false);
    },
  });

  // Generate preview from files
  const generatePreview = (files: CodeFile[]) => {
    const mainTsx = files.find(f => f.name.endsWith('.tsx') || f.name.endsWith('.jsx'));
    const cssFile = files.find(f => f.name.endsWith('.css'));
    
    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { margin: 0; font-family: 'Inter', system-ui, sans-serif; }
    ${cssFile?.content || ''}
  </style>
</head>
<body>
  <div id="root">
    <div class="min-h-screen bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center">
      <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-8 text-center max-w-lg">
        <h1 class="text-4xl font-bold text-white mb-4">SynapseAI Preview</h1>
        <p class="text-white/80 mb-6">Your generated application preview</p>
        <pre class="text-left text-xs text-white/60 bg-black/20 rounded-lg p-4 overflow-auto max-h-60">${mainTsx?.content?.slice(0, 500) || 'No code generated yet'}...</pre>
      </div>
    </div>
  </div>
</body>
</html>`;
    setPreviewHtml(html);
  };

  const handleSendMessage = useCallback(async (content: string, techniques: PromptTechnique[]) => {
    // Create session if none exists
    if (!activeSessionId) {
      const title = content.slice(0, 50) + (content.length > 50 ? "..." : "");
      try {
        await createSessionMutation.mutateAsync({
          title,
          model: selectedModel.id,
          preview: content.slice(0, 100),
        });
      } catch (error) {
        console.error("Failed to create session:", error);
        return;
      }
    }

    // Add optimistic user message
    const tempUserMessage: Message = {
      id: `temp-user-${Date.now()}`,
      role: "user",
      content,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, tempUserMessage]);

    // Set up reasoning tree
    setReasoningTree({
      id: "r1",
      type: "thought",
      content: "Analyzing request and determining optimal approach...",
      status: "running",
      children: [
        { id: "r2", type: "action", content: "Applying " + techniques.map(t => t.shortName).join(" + ") + " techniques", status: "pending", tool: "PromptEngine" },
        { id: "r3", type: "observation", content: "Evaluating context and generating response", status: "pending" },
      ],
    });

    // Check if this is a code generation request
    const isCodeRequest = content.toLowerCase().includes("create") || 
                          content.toLowerCase().includes("build") || 
                          content.toLowerCase().includes("make") ||
                          content.toLowerCase().includes("generate");

    if (isCodeRequest) {
      // Start flow visualization
      setFlowNodes(prev => prev.map((n, i) => ({
        ...n,
        status: i === 0 ? "running" as const : "pending" as const,
      })));
      setIsFlowRunning(true);
      
      // Generate code
      generateCodeMutation.mutate(content);
    }

    // Send message to API
    sendMessageMutation.mutate({
      content,
      techniques: techniques.map(t => t.id),
      model: selectedModel.id,
    });
  }, [activeSessionId, selectedModel, createSessionMutation, sendMessageMutation, generateCodeMutation]);

  const handleNewSession = useCallback(() => {
    setActiveSessionId(null);
    setMessages([]);
    setReasoningTree(null);
    setCodeFiles([]);
    setPreviewHtml("");
    setFlowNodes(defaultFlowNodes);
    setWorkspaceTab("chat");
  }, []);

  const handleTechniqueToggle = useCallback((technique: PromptTechnique) => {
    setActiveTechniques((prev) =>
      prev.some((t) => t.id === technique.id)
        ? prev.filter((t) => t.id !== technique.id)
        : [...prev, technique]
    );
  }, []);

  const handleCodeChange = useCallback((id: string, content: string) => {
    setCodeFiles((prev) =>
      prev.map((f) => {
        if (f.id === id) {
          return {
            ...f,
            content,
            isModified: true,
            previousContent: f.previousContent || f.content,
            version: (f.version || 1) + 1,
          };
        }
        return f;
      })
    );
  }, []);

  const handleOnboardingComplete = () => {
    localStorage.setItem("synapse-onboarding-complete", "true");
  };

  // Load messages when session changes
  useEffect(() => {
    if (activeSessionId) {
      fetch(`/api/sessions/${activeSessionId}/messages`)
        .then(res => res.json())
        .then(data => {
          const loadedMessages: Message[] = data.map((m: { id: string; role: string; content: string; createdAt: string; model?: string; tokenCount?: number }) => ({
            id: m.id,
            role: m.role as "user" | "assistant",
            content: m.content,
            timestamp: new Date(m.createdAt),
            model: m.model,
            tokenCount: m.tokenCount,
          }));
          setMessages(loadedMessages);
        })
        .catch(console.error);
    }
  }, [activeSessionId]);

  const sidebarStyle = {
    "--sidebar-width": "280px",
    "--sidebar-width-icon": "3.5rem",
  } as React.CSSProperties;

  const isLoading = sendMessageMutation.isPending || generateCodeMutation.isPending;

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex h-screen w-full">
        <AppSidebar
          models={availableModels}
          selectedModel={selectedModel}
          onModelChange={setSelectedModel}
          languages={availableLanguages}
          selectedLanguage={selectedLanguage}
          onLanguageChange={setSelectedLanguage}
          sessions={sessions.map(s => ({
            id: s.id,
            title: s.title,
            preview: s.preview || "",
            messageCount: 0,
            updatedAt: new Date(s.updatedAt),
            model: s.model,
          }))}
          activeSessionId={activeSessionId}
          onSessionSelect={setActiveSessionId}
          onNewSession={handleNewSession}
          onSessionRename={(id) => console.log("Rename:", id)}
          onSessionArchive={(id) => console.log("Archive:", id)}
          onSessionDelete={(id) => deleteSessionMutation.mutate(id)}
          onOpenSettings={() => console.log("Settings")}
          onOpenHelp={() => setShowOnboarding(true)}
        />

        <SidebarInset className="flex flex-col flex-1 min-w-0">
          {/* API Status Alert */}
          {status && !status.configured && (
            <Alert className="mx-4 mt-2 border-amber-500/50 bg-amber-500/10">
              <AlertCircle className="h-4 w-4 text-amber-500" />
              <AlertDescription className="text-amber-600 dark:text-amber-400 text-sm">
                Configure GEMINI_API_KEY for full AI capabilities. Currently running in demo mode.
              </AlertDescription>
            </Alert>
          )}

          {/* Header with workspace tabs */}
          <header className="flex items-center justify-between gap-2 px-2 py-1.5 border-b flex-shrink-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="flex items-center gap-2">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              
              {/* Workspace tabs */}
              <div className="flex items-center border rounded-lg p-0.5 bg-muted/50">
                <Button
                  variant={workspaceTab === "chat" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-7 gap-1.5 text-xs"
                  onClick={() => setWorkspaceTab("chat")}
                  data-testid="tab-chat"
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Chat</span>
                </Button>
                <Button
                  variant={workspaceTab === "code" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-7 gap-1.5 text-xs"
                  onClick={() => setWorkspaceTab("code")}
                  data-testid="tab-code"
                >
                  <Code className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Code</span>
                </Button>
                <Button
                  variant={workspaceTab === "preview" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-7 gap-1.5 text-xs"
                  onClick={() => setWorkspaceTab("preview")}
                  data-testid="tab-preview"
                >
                  <Eye className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Preview</span>
                </Button>
                <Button
                  variant={workspaceTab === "flow" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-7 gap-1.5 text-xs"
                  onClick={() => setWorkspaceTab("flow")}
                  data-testid="tab-flow"
                >
                  <GitBranch className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Flow</span>
                </Button>
                <Button
                  variant={workspaceTab === "agent" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-7 gap-1.5 text-xs"
                  onClick={() => setWorkspaceTab("agent")}
                  data-testid="tab-agent"
                >
                  <Bot className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Agent</span>
                </Button>
              </div>
            </div>
            
            <div className="flex items-center gap-1">
              <Badge variant="outline" className="text-[10px] hidden sm:flex gap-1.5 neon-text-subtle">
                <Sparkles className="h-3 w-3" />
                {selectedModel.name}
                {selectedModel.isFree && <span className="text-green-500">Free</span>}
              </Badge>
              <ThemeToggle />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsFullscreen(!isFullscreen)}
                data-testid="button-toggle-fullscreen"
              >
                {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsInspectorOpen(!isInspectorOpen)}
                data-testid="button-toggle-inspector"
              >
                {isInspectorOpen ? (
                  <PanelRightClose className="h-4 w-4" />
                ) : (
                  <PanelRightOpen className="h-4 w-4" />
                )}
              </Button>
            </div>
          </header>

          {/* Main workspace area */}
          <div className="flex flex-1 min-h-0">
            <main className="flex-1 min-w-0">
              {workspaceTab === "chat" && (
                <ChatArea
                  messages={messages}
                  isLoading={isLoading}
                  activeTechniques={activeTechniques}
                  onTechniqueRemove={(id) => setActiveTechniques((prev) => prev.filter((t) => t.id !== id))}
                  onOpenTechniqueLibrary={() => setIsTechniqueLibraryOpen(true)}
                  onSendMessage={handleSendMessage}
                  onCopyMessage={(id) => {
                    const msg = messages.find(m => m.id === id);
                    if (msg) navigator.clipboard.writeText(msg.content);
                  }}
                  onRegenerateMessage={(id) => {
                    const msg = messages.find(m => m.id === id);
                    if (msg && msg.role === "user") {
                      handleSendMessage(msg.content, activeTechniques);
                    }
                  }}
                  onFeedback={(id, type) => console.log("Feedback:", id, type)}
                  modelName={selectedModel.name}
                  compressionStats={{
                    ratio: 4.2,
                    tokensUsed: messages.reduce((acc, m) => acc + (m.tokenCount || 0), 0),
                    maxTokens: 128000,
                    tokensSaved: 0,
                  }}
                />
              )}
              
              {workspaceTab === "code" && (
                <div className="h-full p-4">
                  {codeFiles.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-8">
                      <Code className="h-16 w-16 text-muted-foreground/30 mb-4" />
                      <h3 className="text-lg font-medium mb-2">No Code Generated Yet</h3>
                      <p className="text-sm text-muted-foreground max-w-md mb-4">
                        Ask me to create, build, or generate something and I'll write the code for you.
                      </p>
                      <Button onClick={() => setWorkspaceTab("chat")} data-testid="button-go-to-chat">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Start Chatting
                      </Button>
                    </div>
                  ) : (
                    <CodeEditorWithDiff
                      files={codeFiles}
                      activeFileId={activeFileId}
                      onFileSelect={setActiveFileId}
                      onCodeChange={handleCodeChange}
                      onRun={() => {
                        generatePreview(codeFiles);
                        setWorkspaceTab("preview");
                      }}
                      onReset={() => setCodeFiles([])}
                      isFullscreen={isFullscreen}
                      onToggleFullscreen={() => setIsFullscreen(!isFullscreen)}
                      showDiff={true}
                    />
                  )}
                </div>
              )}
              
              {workspaceTab === "preview" && (
                <div className="h-full p-4">
                  <LivePreview
                    htmlContent={previewHtml}
                    isLoading={generateCodeMutation.isPending}
                    onRefresh={() => generatePreview(codeFiles)}
                  />
                </div>
              )}
              
              {workspaceTab === "flow" && (
                <div className="h-full p-4">
                  <SystemsThinkingFlow
                    nodes={flowNodes}
                    title="Generation Pipeline"
                    isRunning={isFlowRunning}
                    onStart={() => setIsFlowRunning(true)}
                    onPause={() => setIsFlowRunning(false)}
                    onReset={() => setFlowNodes(defaultFlowNodes)}
                    onNodeClick={(id) => console.log("Node clicked:", id)}
                  />
                </div>
              )}
              
              {workspaceTab === "agent" && (
                <div className="h-full p-4">
                  <AgentBuilder
                    config={agentConfig}
                    onConfigChange={setAgentConfig}
                    onDeploy={() => console.log("Deploying agent:", agentConfig)}
                    onTest={() => console.log("Testing agent:", agentConfig)}
                  />
                </div>
              )}
            </main>

            <InspectorPanel
              isOpen={isInspectorOpen}
              onClose={() => setIsInspectorOpen(false)}
              reasoningTree={reasoningTree}
              metrics={defaultMetrics}
              memorySlots={defaultMemorySlots}
              settings={settings}
              onSettingsChange={(key, value) => setSettings((prev) => ({ ...prev, [key]: value }))}
            />
          </div>
        </SidebarInset>

        <PromptTechniqueLibrary
          isOpen={isTechniqueLibraryOpen}
          onClose={() => setIsTechniqueLibraryOpen(false)}
          techniques={allTechniques}
          selectedTechniques={activeTechniques}
          onTechniqueToggle={handleTechniqueToggle}
          onApply={() => setIsTechniqueLibraryOpen(false)}
        />
        
        <OnboardingGuide
          isOpen={showOnboarding}
          onClose={() => setShowOnboarding(false)}
          onComplete={handleOnboardingComplete}
        />
      </div>
    </SidebarProvider>
  );
}
