import { useState } from "react";
import { Plus, Settings, HelpCircle, Sparkles } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import ModelSelector, { type AIModel } from "./ModelSelector";
import LanguageSelector, { type Language } from "./LanguageSelector";
import SessionItem, { type Session } from "./SessionItem";

interface AppSidebarProps {
  models: AIModel[];
  selectedModel: AIModel;
  onModelChange: (model: AIModel) => void;
  languages: Language[];
  selectedLanguage: Language;
  onLanguageChange: (language: Language) => void;
  sessions: Session[];
  activeSessionId: string | null;
  onSessionSelect: (id: string) => void;
  onNewSession: () => void;
  onSessionRename: (id: string) => void;
  onSessionArchive: (id: string) => void;
  onSessionDelete: (id: string) => void;
  onOpenSettings: () => void;
  onOpenHelp: () => void;
}

export default function AppSidebar({
  models,
  selectedModel,
  onModelChange,
  languages,
  selectedLanguage,
  onLanguageChange,
  sessions,
  activeSessionId,
  onSessionSelect,
  onNewSession,
  onSessionRename,
  onSessionArchive,
  onSessionDelete,
  onOpenSettings,
  onOpenHelp,
}: AppSidebarProps) {
  return (
    <Sidebar className="border-r border-sidebar-border">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center h-8 w-8 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <div>
            <h1 className="text-base font-semibold">SynapseAI</h1>
            <p className="text-[10px] text-muted-foreground">Self-Evolving Agent</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="px-2 text-xs">Model</SidebarGroupLabel>
          <SidebarGroupContent className="px-2">
            <ModelSelector
              models={models}
              selectedModel={selectedModel}
              onModelChange={onModelChange}
            />
          </SidebarGroupContent>
        </SidebarGroup>

        <Separator className="my-2" />

        <SidebarGroup className="flex-1 min-h-0">
          <div className="flex items-center justify-between px-2 mb-2">
            <SidebarGroupLabel className="text-xs mb-0 pb-0">Sessions</SidebarGroupLabel>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={onNewSession}
              data-testid="button-new-session"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <SidebarGroupContent className="px-2">
            <ScrollArea className="h-[calc(100vh-360px)]">
              <div className="space-y-1">
                {sessions.map((session) => (
                  <SessionItem
                    key={session.id}
                    session={session}
                    isActive={session.id === activeSessionId}
                    onClick={() => onSessionSelect(session.id)}
                    onRename={() => onSessionRename(session.id)}
                    onArchive={() => onSessionArchive(session.id)}
                    onDelete={() => onSessionDelete(session.id)}
                  />
                ))}
              </div>
            </ScrollArea>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-2">
        <Separator className="mb-2" />
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={onOpenSettings} data-testid="button-settings">
              <Settings className="h-4 w-4" />
              <span>Settings</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={onOpenHelp} data-testid="button-help">
              <HelpCircle className="h-4 w-4" />
              <span>Help & Docs</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
        <div className="mt-2 px-2">
          <LanguageSelector
            languages={languages}
            selectedLanguage={selectedLanguage}
            onLanguageChange={onLanguageChange}
          />
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
