import { useState, useRef, useEffect } from "react";
import { Copy, Check, Play, Download, Maximize2, Minimize2, RotateCcw, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DiffViewer from "./DiffViewer";

export interface CodeFile {
  id: string;
  name: string;
  language: string;
  content: string;
  isModified?: boolean;
  version?: number;
  previousContent?: string;
}

interface CodeEditorProps {
  files: CodeFile[];
  activeFileId: string;
  onFileSelect: (id: string) => void;
  onCodeChange: (id: string, content: string) => void;
  onRun?: () => void;
  onReset?: () => void;
  isRunning?: boolean;
  isFullscreen?: boolean;
  onToggleFullscreen?: () => void;
  showDiff?: boolean;
}

const languageColors: Record<string, string> = {
  javascript: "text-yellow-400",
  typescript: "text-blue-400",
  python: "text-green-400",
  html: "text-orange-400",
  css: "text-pink-400",
  json: "text-amber-400",
  markdown: "text-gray-400",
};

export default function CodeEditorWithDiff({
  files,
  activeFileId,
  onFileSelect,
  onCodeChange,
  onRun,
  onReset,
  isRunning = false,
  isFullscreen = false,
  onToggleFullscreen,
  showDiff = false,
}: CodeEditorProps) {
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<"editor" | "diff">("editor");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const activeFile = files.find((f) => f.id === activeFileId);

  const handleCopy = () => {
    if (activeFile) {
      navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    if (activeFile) {
      const blob = new Blob([activeFile.content], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = activeFile.name;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  useEffect(() => {
    if (textareaRef.current && activeFile) {
      textareaRef.current.value = activeFile.content;
    }
  }, [activeFileId, activeFile]);

  const canShowDiff = showDiff && activeFile?.previousContent;

  return (
    <div className={`flex flex-col h-full border rounded-lg overflow-hidden bg-card ${isFullscreen ? "fixed inset-4 z-50" : ""}`}>
      {/* File tabs */}
      <div className="flex items-center justify-between border-b bg-muted/30 px-2">
        <ScrollArea className="flex-1">
          <div className="flex items-center gap-1 py-1">
            {files.map((file) => (
              <button
                key={file.id}
                onClick={() => onFileSelect(file.id)}
                className={`
                  flex items-center gap-2 px-3 py-1.5 text-sm rounded-md transition-colors whitespace-nowrap
                  ${file.id === activeFileId 
                    ? "bg-background text-foreground" 
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                  }
                `}
                data-testid={`tab-file-${file.id}`}
              >
                <span className={`text-xs ${languageColors[file.language] || "text-gray-400"}`}>
                  {file.language === "javascript" ? "JS" : 
                   file.language === "typescript" ? "TS" :
                   file.language === "python" ? "PY" :
                   file.language.toUpperCase().slice(0, 2)}
                </span>
                <span>{file.name}</span>
                {file.isModified && <span className="w-1.5 h-1.5 rounded-full bg-primary" />}
                {file.version && file.version > 1 && (
                  <Badge variant="secondary" className="text-[9px] px-1 py-0">
                    v{file.version}
                  </Badge>
                )}
              </button>
            ))}
          </div>
        </ScrollArea>
        
        <div className="flex items-center gap-1 px-2">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleCopy} data-testid="button-copy-code">
            {copied ? <Check className="h-3.5 w-3.5 text-green-500" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleDownload} data-testid="button-download-code">
            <Download className="h-3.5 w-3.5" />
          </Button>
          {onReset && (
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onReset} data-testid="button-reset-code">
              <RotateCcw className="h-3.5 w-3.5" />
            </Button>
          )}
          {onToggleFullscreen && (
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onToggleFullscreen} data-testid="button-fullscreen">
              {isFullscreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
            </Button>
          )}
          {onRun && (
            <Button 
              size="sm" 
              className="h-7 gap-1.5 ml-2" 
              onClick={onRun} 
              disabled={isRunning}
              data-testid="button-run-code"
            >
              <Play className="h-3.5 w-3.5" />
              {isRunning ? "Running..." : "Run"}
            </Button>
          )}
        </div>
      </div>

      {/* View mode tabs */}
      {canShowDiff && (
        <Tabs 
          value={viewMode} 
          onValueChange={(v) => setViewMode(v as "editor" | "diff")}
          className="border-b"
        >
          <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
            <TabsTrigger 
              value="editor"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
              data-testid="tab-editor"
            >
              <span className="text-xs">Editor</span>
            </TabsTrigger>
            <TabsTrigger 
              value="diff"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
              data-testid="tab-diff"
            >
              <History className="h-3.5 w-3.5 mr-1.5" />
              <span className="text-xs">Changes</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      )}

      {/* Content area */}
      <div className="flex-1 overflow-hidden">
        {viewMode === "diff" && canShowDiff ? (
          <div className="h-full p-4 overflow-auto">
            <DiffViewer
              oldContent={activeFile.previousContent!}
              newContent={activeFile.content}
              fileName={activeFile.name}
              onAccept={() => setViewMode("editor")}
              onReject={() => {
                onCodeChange(activeFile.id, activeFile.previousContent!);
                setViewMode("editor");
              }}
            />
          </div>
        ) : (
          <div className="flex-1 flex overflow-hidden h-full">
            {/* Line numbers */}
            <div className="w-12 flex-shrink-0 bg-muted/20 text-muted-foreground text-right text-xs font-mono py-3 pr-2 select-none overflow-hidden">
              {activeFile?.content.split("\n").map((_, i) => (
                <div key={i} className="leading-6 h-6">
                  {i + 1}
                </div>
              ))}
            </div>
            
            {/* Editor */}
            <textarea
              ref={textareaRef}
              value={activeFile?.content || ""}
              onChange={(e) => activeFile && onCodeChange(activeFile.id, e.target.value)}
              className="flex-1 bg-transparent text-sm font-mono p-3 resize-none focus:outline-none leading-6"
              spellCheck={false}
              data-testid="textarea-code"
            />
          </div>
        )}
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 py-1 border-t bg-muted/30 text-xs text-muted-foreground">
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
            {activeFile?.language || "plain text"}
          </Badge>
          <span>Lines: {activeFile?.content.split("\n").length || 0}</span>
          <span>Chars: {activeFile?.content.length || 0}</span>
        </div>
        <div className="flex items-center gap-2">
          <span>UTF-8</span>
          <span>LF</span>
        </div>
      </div>
    </div>
  );
}
