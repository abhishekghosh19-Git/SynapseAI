import MessageBubble, { type Message } from "../MessageBubble";

// todo: remove mock functionality
const mockMessages: Message[] = [
  {
    id: "1",
    role: "user",
    content: "Can you help me understand how Chain of Thought prompting works?",
    timestamp: new Date(Date.now() - 60000),
  },
  {
    id: "2",
    role: "assistant",
    content: `Chain of Thought (CoT) prompting is a technique that encourages the AI to break down complex problems into intermediate reasoning steps.

**How it works:**
1. Instead of jumping directly to an answer, the model explains its reasoning step-by-step
2. This improves accuracy on math, logic, and multi-step reasoning tasks
3. You can trigger it with "Let's think step by step" or by providing examples with reasoning

**Example:**
Q: If a train travels 120 km in 2 hours, what's its speed?
A: Let me solve this step by step:
- Distance = 120 km
- Time = 2 hours  
- Speed = Distance / Time
- Speed = 120 / 2 = 60 km/h

This technique can improve accuracy by 17-58% on complex reasoning tasks!`,
    timestamp: new Date(),
    model: "Gemini 2.5 Flash",
    tokenCount: 156,
    compressionRatio: 3.2,
  },
];

export default function MessageBubbleExample() {
  return (
    <div className="flex flex-col gap-6 max-w-2xl">
      {mockMessages.map((message) => (
        <MessageBubble
          key={message.id}
          message={message}
          onCopy={() => console.log("Copied message")}
          onRegenerate={() => console.log("Regenerating...")}
          onFeedback={(type) => console.log(`Feedback: ${type}`)}
        />
      ))}
    </div>
  );
}
