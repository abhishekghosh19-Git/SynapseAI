import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export interface MetricData {
  label: string;
  value: string | number;
  unit?: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  description?: string;
}

interface PerformanceMetricProps {
  metric: MetricData;
  icon?: React.ReactNode;
}

export default function PerformanceMetric({ metric, icon }: PerformanceMetricProps) {
  const TrendIcon = metric.trend === "up" ? TrendingUp : metric.trend === "down" ? TrendingDown : Minus;
  const trendColor = metric.trend === "up" ? "text-green-500" : metric.trend === "down" ? "text-red-500" : "text-muted-foreground";

  return (
    <Card className="hover-elevate" data-testid={`metric-${metric.label.toLowerCase().replace(/\s+/g, "-")}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
              {metric.label}
            </p>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-2xl font-semibold">{metric.value}</span>
              {metric.unit && (
                <span className="text-sm text-muted-foreground">{metric.unit}</span>
              )}
            </div>
            {metric.description && (
              <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
                {metric.description}
              </p>
            )}
          </div>
          <div className="flex flex-col items-end gap-1">
            {icon && <div className="text-primary">{icon}</div>}
            {metric.trend && metric.trendValue && (
              <div className={`flex items-center gap-0.5 text-xs ${trendColor}`}>
                <TrendIcon className="h-3 w-3" />
                <span>{metric.trendValue}</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
