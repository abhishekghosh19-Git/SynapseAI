import CompressionIndicator from "../CompressionIndicator";

export default function CompressionIndicatorExample() {
  return (
    <div className="w-full max-w-2xl border rounded-lg overflow-hidden">
      <CompressionIndicator
        compressionRatio={4.2}
        tokensUsed={24500}
        maxTokens={128000}
        tokensSaved={78000}
      />
    </div>
  );
}
