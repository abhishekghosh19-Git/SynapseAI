import { useState } from "react";
import PromptTechniqueBadge, { type PromptTechnique } from "../PromptTechniqueBadge";

// todo: remove mock functionality
const mockTechniques: PromptTechnique[] = [
  {
    id: "cot",
    name: "Chain of Thought",
    shortName: "CoT",
    description: "Step-by-step reasoning before answering",
    category: "reasoning",
    useCases: ["Math problems", "Logic puzzles", "Complex decisions"],
  },
  {
    id: "react",
    name: "ReAct",
    shortName: "ReAct",
    description: "Reasoning + Acting with tool use",
    category: "reasoning",
    useCases: ["Research tasks", "Data retrieval", "Multi-step actions"],
  },
  {
    id: "rag",
    name: "Retrieval Augmented",
    shortName: "RAG",
    description: "Retrieve external knowledge",
    category: "retrieval",
    useCases: ["Factual queries", "Documentation", "Research"],
  },
];

export default function PromptTechniqueBadgeExample() {
  const [techniques, setTechniques] = useState(mockTechniques);
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div className="flex flex-wrap gap-2">
      {techniques.map((technique) => (
        <PromptTechniqueBadge
          key={technique.id}
          technique={technique}
          isRemovable
          isSelected={selected === technique.id}
          onClick={() => setSelected(technique.id === selected ? null : technique.id)}
          onRemove={() => setTechniques((prev) => prev.filter((t) => t.id !== technique.id))}
        />
      ))}
    </div>
  );
}
