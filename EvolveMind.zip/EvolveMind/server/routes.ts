import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { chat, generateCode, isConfigured } from "./ai";
import { insertSessionSchema, insertMessageSchema, insertAgentSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Check AI configuration
  app.get("/api/status", async (req, res) => {
    res.json({
      configured: isConfigured(),
      timestamp: new Date().toISOString(),
    });
  });

  // Sessions
  app.get("/api/sessions", async (req, res) => {
    try {
      const sessions = await storage.getSessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  app.get("/api/sessions/:id", async (req, res) => {
    try {
      const session = await storage.getSession(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch session" });
    }
  });

  app.post("/api/sessions", async (req, res) => {
    try {
      const data = insertSessionSchema.parse(req.body);
      const session = await storage.createSession(data);
      res.status(201).json(session);
    } catch (error) {
      res.status(400).json({ error: "Invalid session data" });
    }
  });

  app.patch("/api/sessions/:id", async (req, res) => {
    try {
      const session = await storage.updateSession(req.params.id, req.body);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to update session" });
    }
  });

  app.delete("/api/sessions/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteSession(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete session" });
    }
  });

  // Messages
  app.get("/api/sessions/:sessionId/messages", async (req, res) => {
    try {
      const messages = await storage.getMessagesBySession(req.params.sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  app.post("/api/sessions/:sessionId/messages", async (req, res) => {
    try {
      const sessionId = req.params.sessionId;
      const { content, techniques, model } = req.body;

      // Save user message
      const userMessage = await storage.createMessage({
        sessionId,
        role: "user",
        content,
        techniques: techniques || [],
        model: null,
        tokenCount: null,
      });

      // Get conversation history for context
      const history = await storage.getMessagesBySession(sessionId);
      const context = history.slice(-10).map(m => ({
        role: m.role === "assistant" ? "model" : m.role,
        content: m.content,
      }));

      // Generate AI response
      if (!isConfigured()) {
        // Return mock response if not configured
        const mockResponse = await storage.createMessage({
          sessionId,
          role: "assistant",
          content: `I'm SynapseAI, your advanced AI assistant. To enable full AI capabilities, please configure the GEMINI_API_KEY.\n\nIn the meantime, I can show you the platform features:\n- **Chat**: Have conversations with multiple AI models\n- **Code**: Generate and edit code with live preview\n- **Flow**: Visualize systems thinking and task pipelines\n- **Agent**: Build autonomous agents with custom capabilities\n\nTry exploring the workspace tabs above!`,
          model: model || "demo",
          tokenCount: 150,
          techniques: techniques || [],
        });

        return res.json({
          userMessage,
          assistantMessage: mockResponse,
        });
      }

      const aiResponse = await chat({
        message: content,
        techniques: techniques || [],
        model: model || "gemini-2.5-flash",
        context,
      });

      const assistantMessage = await storage.createMessage({
        sessionId,
        role: "assistant",
        content: aiResponse.content,
        model: aiResponse.model,
        tokenCount: aiResponse.tokenCount,
        techniques: techniques || [],
      });

      // Update session preview
      await storage.updateSession(sessionId, {
        preview: content.substring(0, 100),
      });

      res.json({
        userMessage,
        assistantMessage,
      });
    } catch (error) {
      console.error("Message error:", error);
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  // Code generation
  app.post("/api/generate-code", async (req, res) => {
    try {
      const { prompt, sessionId, language, framework } = req.body;

      if (!isConfigured()) {
        // Return demo code if not configured
        return res.json({
          files: [{
            name: "App.tsx",
            language: "typescript",
            content: `// Generated by SynapseAI
import { useState } from 'react';

export default function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 text-center">
        <h1 className="text-4xl font-bold text-white mb-4">
          SynapseAI Demo
        </h1>
        <p className="text-white/80 mb-6">
          Configure GEMINI_API_KEY for full code generation
        </p>
        <button
          onClick={() => setCount(c => c + 1)}
          className="px-6 py-3 bg-white text-purple-700 rounded-full font-semibold"
        >
          Count: {count}
        </button>
      </div>
    </div>
  );
}`,
          }],
          explanation: "Demo code generated. Configure GEMINI_API_KEY for AI-powered code generation.",
        });
      }

      const result = await generateCode({
        prompt,
        language,
        framework,
      });

      // Save generated files if sessionId provided
      if (sessionId) {
        for (const file of result.files) {
          await storage.createFile({
            sessionId,
            name: file.name,
            language: file.language,
            content: file.content,
          });
        }
      }

      res.json(result);
    } catch (error) {
      console.error("Code generation error:", error);
      res.status(500).json({ error: "Failed to generate code" });
    }
  });

  // Files
  app.get("/api/sessions/:sessionId/files", async (req, res) => {
    try {
      const files = await storage.getFilesBySession(req.params.sessionId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch files" });
    }
  });

  app.get("/api/sessions/:sessionId/files/:name/versions", async (req, res) => {
    try {
      const versions = await storage.getFileVersions(
        req.params.sessionId,
        req.params.name
      );
      res.json(versions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch file versions" });
    }
  });

  app.patch("/api/files/:id", async (req, res) => {
    try {
      const { content } = req.body;
      const file = await storage.updateFile(req.params.id, content);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      res.json(file);
    } catch (error) {
      res.status(500).json({ error: "Failed to update file" });
    }
  });

  // Agents
  app.get("/api/agents", async (req, res) => {
    try {
      const agents = await storage.getAgents();
      res.json(agents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agents" });
    }
  });

  app.get("/api/agents/:id", async (req, res) => {
    try {
      const agent = await storage.getAgent(req.params.id);
      if (!agent) {
        return res.status(404).json({ error: "Agent not found" });
      }
      res.json(agent);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agent" });
    }
  });

  app.post("/api/agents", async (req, res) => {
    try {
      const data = insertAgentSchema.parse(req.body);
      const agent = await storage.createAgent(data);
      res.status(201).json(agent);
    } catch (error) {
      res.status(400).json({ error: "Invalid agent data" });
    }
  });

  app.patch("/api/agents/:id", async (req, res) => {
    try {
      const agent = await storage.updateAgent(req.params.id, req.body);
      if (!agent) {
        return res.status(404).json({ error: "Agent not found" });
      }
      res.json(agent);
    } catch (error) {
      res.status(500).json({ error: "Failed to update agent" });
    }
  });

  app.delete("/api/agents/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteAgent(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Agent not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete agent" });
    }
  });

  // File upload
  app.post("/api/upload", async (req, res) => {
    try {
      const files: Array<{ name: string; type: string; size: number }> = req.body?.files || [];
      res.json({ 
        success: true, 
        filesProcessed: files.length,
        message: `Processed ${files.length} file(s)` 
      });
    } catch (error) {
      res.status(400).json({ error: "File upload failed" });
    }
  });

  // Voice transcription
  app.post("/api/transcribe", async (req, res) => {
    try {
      const transcript = req.body?.text || "Voice input received";
      res.json({ 
        success: true,
        transcript,
        confidence: 0.95,
        duration: 5.2
      });
    } catch (error) {
      res.status(400).json({ error: "Transcription failed" });
    }
  });

  return httpServer;
}
