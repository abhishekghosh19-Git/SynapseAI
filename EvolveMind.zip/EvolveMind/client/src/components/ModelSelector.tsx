import { Check, ChevronDown, Zap, Brain, Sparkles, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

export interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  isFree: boolean;
  icon: "zap" | "brain" | "sparkles" | "globe";
}

const iconMap = {
  zap: Zap,
  brain: Brain,
  sparkles: Sparkles,
  globe: Globe,
};

interface ModelSelectorProps {
  models: AIModel[];
  selectedModel: AIModel;
  onModelChange: (model: AIModel) => void;
}

export default function ModelSelector({
  models,
  selectedModel,
  onModelChange,
}: ModelSelectorProps) {
  const SelectedIcon = iconMap[selectedModel.icon];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className="w-full justify-between gap-2 h-10"
          data-testid="button-model-selector"
        >
          <div className="flex items-center gap-2 truncate">
            <SelectedIcon className="h-4 w-4 text-primary flex-shrink-0" />
            <span className="truncate font-medium">{selectedModel.name}</span>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            {selectedModel.isFree && (
              <Badge variant="secondary" className="text-xs px-1.5 py-0">
                Free
              </Badge>
            )}
            <ChevronDown className="h-4 w-4 opacity-50" />
          </div>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-72">
        <DropdownMenuLabel>Select AI Model</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {models.map((model) => {
          const Icon = iconMap[model.icon];
          const isSelected = model.id === selectedModel.id;
          return (
            <DropdownMenuItem
              key={model.id}
              onClick={() => onModelChange(model)}
              className="flex items-start gap-3 py-3 cursor-pointer"
              data-testid={`menu-item-model-${model.id}`}
            >
              <Icon className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{model.name}</span>
                  {model.isFree && (
                    <Badge variant="secondary" className="text-xs px-1.5 py-0">
                      Free
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5 truncate">
                  {model.provider} - {model.description}
                </p>
              </div>
              {isSelected && <Check className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
