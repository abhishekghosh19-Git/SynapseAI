import { X } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export interface PromptTechnique {
  id: string;
  name: string;
  shortName: string;
  description: string;
  category: "reasoning" | "retrieval" | "refinement" | "framework" | "advanced";
  useCases: string[];
}

interface PromptTechniqueBadgeProps {
  technique: PromptTechnique;
  onRemove?: () => void;
  isRemovable?: boolean;
  onClick?: () => void;
  isSelected?: boolean;
}

const categoryColors: Record<string, string> = {
  reasoning: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20",
  retrieval: "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20",
  refinement: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20",
  framework: "bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20",
  advanced: "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20",
};

export default function PromptTechniqueBadge({
  technique,
  onRemove,
  isRemovable = false,
  onClick,
  isSelected = false,
}: PromptTechniqueBadgeProps) {
  return (
    <Badge
      variant="outline"
      className={`
        cursor-pointer transition-all gap-1 px-2 py-1 text-xs font-medium
        ${categoryColors[technique.category]}
        ${isSelected ? "ring-2 ring-primary ring-offset-1" : ""}
        ${onClick ? "hover-elevate" : ""}
      `}
      onClick={onClick}
      data-testid={`badge-technique-${technique.id}`}
    >
      {technique.shortName}
      {isRemovable && onRemove && (
        <X
          className="h-3 w-3 ml-0.5 hover:text-destructive cursor-pointer"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
        />
      )}
    </Badge>
  );
}
